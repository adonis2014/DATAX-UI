

package com.iharding.generator;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.StringReader;
import java.io.StringWriter;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.Properties;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;

import org.apache.velocity.Template;
import org.apache.velocity.VelocityContext;
import org.apache.velocity.app.Velocity;
import org.apache.velocity.app.tools.VelocityFormatter;

import com.iharding.generator.strutsgen.Util;
import com.iharding.generator.xml.Build;
import com.iharding.generator.xml.Database;
import com.iharding.generator.xml.Strutscreator;

/**
 *  Description of the Class
 *
 *@author     Administrator
 *created    September 28, 2002
 */
public abstract class Generator {
  protected String outputdir;
  protected VelocityContext strutsContext;
  protected Util util;
  protected long generatedByteCount;
  protected Transformer transformer;
  protected String xsltFile;
  protected String layoutDir;
  protected String templateDir;

  public void setXsltFile(String xsltFile) {
    this.xsltFile = xsltFile;
  }

  public String getXsltFile() {
    return xsltFile;
  }

  public void setLayoutDir(String layoutDir) {
    this.layoutDir = layoutDir;
  }

  public String getLayoutDir() {
    return layoutDir;
  }

  public void setTemplateDir(String templateDir) {
    this.templateDir = templateDir;
  }

  public String getTemplateDir() {
    return templateDir;
  }

  public void setOutputDirectory(String path) {
    if (!path.equals("")) {
      outputdir = path;
    } else {
      outputdir = ".";
    }
    if (!outputdir.endsWith(File.separator)) {
      outputdir = outputdir + File.separator;
    }
  }

  public long getGeneratedByteCount() {
    return generatedByteCount;
  }

  protected abstract String getPath(String strPackage);
  protected abstract void createDefaultDir();

  protected void copyDirectoryLayout() {
    File src = new File(layoutDir);
    File[] content = src.listFiles();
    for (int i = 0; i < content.length; i++) {
      copy(content[i]);
    }
  }

    /*
        Prepares Directory structure and populates velocity context with global objects
        and formatting utilities.

    */

  protected void generateFiles(Strutscreator tree) throws Exception {
    generatedByteCount = 0;
    Properties prop = new Properties();
    prop.put("resource.manager.logwhenfound", "false");
    prop.put("resource.loader", "class");
    prop.put("class.resource.loader.cache", "true");
    prop.put("class.resource.loader.class",
        "org.apache.velocity.runtime.resource.loader.ClasspathResourceLoader");
    prop.put("class.resource.loader.modificationCheckInterval", "0");
    Velocity.init(prop);

    strutsContext = new VelocityContext();
    VelocityFormatter formatter = new VelocityFormatter(strutsContext);

    Database db = tree.getDatabase();
    Build build = tree.getBuild();
    util = new Util();
    util.setDbms(db.getDbms());
    util.setGlobalValueRef(tree.getGlobalValueRef());
    util.setDateFormat(build.getDateFormat());
    strutsContext.put("dateFormat", build.getDateFormat());
    strutsContext.put("formatter", formatter);
    strutsContext.put("util", util);
    strutsContext.put("property", tree.getProperty());
    strutsContext.put("database", db);
    strutsContext.put("build", build);
    strutsContext.put("globalReference", tree.getGlobalReference());
    strutsContext.put("globalValueReference", tree.getGlobalValueRef());
    GregorianCalendar cal = new GregorianCalendar();
    strutsContext.put("date", cal);
    strutsContext.put("year", String.valueOf(cal.get(Calendar.YEAR)));

    setOutputDirectory(build.getDirectory());
    File directory = new File(build.getDirectory());
    directory.mkdirs();

    transformer = TransformerFactory.newInstance().newTransformer(new StreamSource(xsltFile));
  }

  protected void applyTemplate(VelocityContext context, String fileName, String template) {
    FileWriter f = null;
    try {
    	File file=new File(fileName);
        file.getParentFile().mkdirs();
      f = new FileWriter(file);
      
      Template t = Velocity.getTemplate( template,"utf-8");
      t.merge(context, f);      
      f.close();
      generatedByteCount += fileSize(fileName);
    } catch (Exception ex) {
      ex.printStackTrace();
    }
  }

    /*
        Version of applyTemplate that returns merged result as String

    */

    protected String applyTemplate(VelocityContext context, String template) {
       StringWriter sw = null;
       try {
         sw = new StringWriter();
         Template t = Velocity.getTemplate(template,"utf-8");

           t.merge(context, sw);
         //generatedByteCount += fileSize(fileName);
       } catch (Exception ex) {
         ex.printStackTrace();
       }
        return sw.toString();
     }




  protected void applyXsltTemplate(VelocityContext context, String fileName, String template) {
    FileOutputStream f = null;
    try {
      f = new FileOutputStream(fileName);
      StringWriter sw = new StringWriter();
      Template t = Velocity.getTemplate( template,"utf-8");
      t.merge(context, sw);
      StringReader sr = new StringReader(sw.toString());
      transformer.transform(new StreamSource(sr), new StreamResult(f));
      f.close();
      generatedByteCount += fileSize(fileName);
    } catch (Exception ex) {
      ex.printStackTrace();
    }
  }

  protected long fileSize(String fileName) {
    File f = new File(fileName);
    return f.length();
  }

  private void copy(File src) {
    int str_start = layoutDir.length() + 1;
    if (src.isDirectory()) {
      File dir = new File(outputdir + src.getPath().substring(str_start));
      if (!dir.exists()) {
        dir.mkdir();
      }
      File[] list = src.listFiles();
      for (int i = 0; i < list.length; i++) {
        copy(list[i]);
      }
    } else {
      File dest = new File(outputdir + src.getPath().substring(str_start));
      if (!dest.exists() || (dest.lastModified() < src.lastModified())) {
        copyFile(src.getPath(), dest.getPath());
        System.out.println(src.getName() + " copied.");
      }
    }
  }

  private void copyFile(String src, String dest) {
    try {
      FileInputStream in = new FileInputStream(src);
      FileOutputStream out = new FileOutputStream(dest);
      int c;

      while ((c = in.read()) != -1) {
        out.write(c);
      }

      in.close();
      out.close();
    } catch (Exception ex) {
      ex.printStackTrace();
    }
  }

}

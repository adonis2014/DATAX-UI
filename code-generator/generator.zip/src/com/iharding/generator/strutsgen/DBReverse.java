package com.iharding.generator.strutsgen;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.HashMap;
import java.util.Properties;

import com.iharding.generator.xml.Attribute;
import com.iharding.generator.xml.Bean;
import com.iharding.generator.xml.Build;
import com.iharding.generator.xml.Column;
import com.iharding.generator.xml.Database;
import com.iharding.generator.xml.PrimaryKey;
import com.iharding.generator.xml.Property;
import com.iharding.generator.xml.Strutscreator;
import com.iharding.generator.xml.Validation;
import com.iharding.generator.xml.XMLException;
import com.iharding.generator.xml.XMLHandler;
import com.iharding.generator.xml.XMLHandlerImpl;

/**
 * FileName: DBReverse.java Aug 19, 2002 8:43:58 PM
 * 
 * @author roel
 * @version 1.1.2
 */
public class DBReverse {
	private Util util = new Util();

	private String dbName = null;

	private String schemaName = null;

	private String templateOutPath = null;

	private String moduleName = null;
	private Connection cconn=null;
	/*
	 * private String srcOutPath=null;
	 * 
	 * private String webAppsOutPath=null;
	 */

	private String outPath = null;

	private String warName = null;

	private String packageName = null;

	private String dbms=null;

	public String getModuleName() {
		return moduleName;
	}

	public void setModuleName(String moduleName) {
		this.moduleName = moduleName;
	}

	public String getPackageName() {
		return packageName;
	}

	public void setPackageName(String packageName) {
		this.packageName = packageName;
	}

	/*
	 * public String getSrcOutPath() { return srcOutPath; }
	 * 
	 * public void setSrcOutPath(String srcOutPath) { this.srcOutPath =
	 * srcOutPath; }
	 */

	public String getWarName() {
		return warName;
	}

	public void setWarName(String warName) {
		this.warName = warName;
	}

	public String getTemplateOutPath() {
		return templateOutPath;
	}

	public void setTemplateOutPath(String templateOutPath) {
		this.templateOutPath = templateOutPath;
	}

	public static void main(String[] args) {
		DBReverse rev = new DBReverse();

		try {
			PropertyMgr prop = new PropertyMgr(Util.prop_file);
			Properties p = prop.getProperties();
			String moduleId = prop.get("module.index");
			int minId = 0;
			int maxId = 9;

			if (moduleId != null && !"".equalsIgnoreCase(moduleId)) {
				minId = Integer.parseInt(moduleId);
				maxId = minId + 1;
			}
			for (int i = minId; i < maxId; i++) {
				rev.setTemplateOutPath(p.getProperty("template.outpath." + i));
				rev.setModuleName(p.getProperty("module.name." + i));
				rev.setPackageName(p.getProperty("package." + i));
				rev.setOutPath("proj.outpath");
				// rev.setSrcOutPath(p.getProperty("src.outpath."+i));
				// rev.setWebAppsOutPath(p.getProperty("webapps.outpath."+i));
				rev.setWarName(p.getProperty("war.name." + i));
				System.out.println("db reverse module:" + rev.getModuleName());
				if (rev.getModuleName() == null) {
					break;
				}
				Strutscreator tree = rev.reverse();
				XMLHandler handler = new XMLHandlerImpl();
				try {
					handler.save(rev.getTemplateOutPath(), tree);
				} catch (XMLException xe) {

				}
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	private String convert(int type, int typeLength, int decimalLength) {
		switch (type) {
		case Types.CHAR:
		case Types.VARCHAR:
			return "string";
		case Types.NUMERIC:
			if (typeLength < 10) {
				return "int";
			} else {
				return "long";
			}
		case Types.DECIMAL:
			if (decimalLength > 0) {
				return "double";
			} else {
				if (typeLength < 10) {
					return "int";
				} else {
					return "long";
				}
			}
		case Types.DOUBLE:
			return "double";
		case Types.BIT:
			return "boolean";
		case Types.TINYINT:
			return "int";
		case Types.SMALLINT:
			return "int";
		case Types.INTEGER:
			return "int";
		case Types.BIGINT:
			return "long";
		case Types.REAL:
		case Types.FLOAT:
			return "float";
		case Types.BINARY:
		case Types.VARBINARY:
		case Types.BLOB:
		case Types.LONGVARBINARY:
			return "blob";
		case Types.CLOB:
		case Types.LONGVARCHAR:
			return "clob";
		case Types.DATE:
			return "timestamp";
		case Types.TIME:
			return "timestamp";
		case Types.TIMESTAMP:
			return "timestamp";
		default:
			return "string";
		}
	}

	/**
	 * Reverse database
	 * 
	 * @param dbms
	 * @param driverClass
	 * @param dbName
	 * @param url
	 * @param user
	 * @param password
	 * @return
	 */
	public Strutscreator reverse() {
		ResultSet rs = null;
		Connection conn = null;
		Strutscreator tree = getDefaultTree();
		try {
			PropertyMgr prop = new PropertyMgr(Util.prop_file);
			Properties p = prop.getProperties();
			String driverClass = p.getProperty("jdbc.driverClassName");
			String dbms = p.getProperty("jdbc.dbms");
			String dbName = p.getProperty("jdbc.dbname");
			String url = p.getProperty("jdbc.url");
			String user = p.getProperty("jdbc.username");
			String password = p.getProperty("jdbc.password");
			String moduleName = this.getModuleName();
			this.dbName = dbName;
			this.dbms=dbms;
			this.schemaName = p.getProperty("jdbc.schemaname");
			Database db = tree.getDatabase();
			db.setDbms(dbms);
			db.setDriver(driverClass);
			db.setUrl(url);
			db.setUser(user);
			db.setPassword(password);
			Class.forName(driverClass);
			conn = DriverManager.getConnection(url, user, password);
			DatabaseMetaData dmd = conn.getMetaData();
			String[] tabletypes = { "TABLE" };
			if ("oracle".equalsIgnoreCase(db.getDbms())){
				rs = dmd.getTables(dbName, schemaName, "%", tabletypes);
			}else if ("mssql".equalsIgnoreCase(db.getDbms())){
				rs = dmd.getTables(null, null, "%", null);
			}else{
				rs = dmd.getTables(dbName, null, null, tabletypes);
			}
			while (rs.next()) {
				if (rs.getString(4).equalsIgnoreCase("table")) {
					String tableName = rs.getString(3);
					if (tableName != null) {
						System.out.println("tables: " + tableName);
						if (tableName.toLowerCase().startsWith(moduleName.toLowerCase() + "_") || "*".equalsIgnoreCase(moduleName)) {
							System.out.println("Importing table " + tableName);
							tree.addBean(getTableDescription(dmd, tableName, moduleName));
						}
					}
				}
			}
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			close(rs);
			close(conn);
		}
		return tree;
	}

	private String getOracleTableComments(String table)  {
		ResultSet rs = null;
		PreparedStatement ps=null;
		String comments="";
		try {
			String sql = "SELECT comments FROM user_tab_comments WHERE table_name='"+table+"'";
			ps=getCommentConnection().prepareStatement(sql);
			rs =ps.executeQuery();
			if (rs.next()) {
				comments=rs.getString("comments");				
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			close(rs);
			try{ps.close();}catch(Exception ex){}
		}		
		return comments;
	}
	
	private Connection getCommentConnection(){
		if (cconn==null){
			try {
				PropertyMgr prop = new PropertyMgr(Util.prop_file);
				Properties p = prop.getProperties();
				String driverClass = p.getProperty("jdbc.driverClassName");
				String url = p.getProperty("jdbc.url");
				String user = p.getProperty("jdbc.username");
				String password = p.getProperty("jdbc.password");
				Class.forName(driverClass);
				cconn = DriverManager.getConnection(url, user, password);				
			}catch (Exception e) {
				e.printStackTrace();
			}	
		}
		return cconn;
		
	}

	private String getOracleColumnComments(String table,String column)  {
		ResultSet rs = null;
		PreparedStatement  ps=null;
		String comments="";
		try {
			String sql = "SELECT comments FROM user_col_comments WHERE table_name='"+table+"' AND column_name = '"+column+"'";
			ps=getCommentConnection().prepareStatement(sql);
			rs =ps.executeQuery();
			if (rs.next()) {
				comments=rs.getString("comments");				
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			close(rs);
			try{ps.close();}catch(Exception ex){				
			}
		}		
		return comments;
	}
	/**
	 * Populate fresh copy of beans from database
	 * 
	 * @param tree
	 * 
	 */
	public void freshenBeans(Strutscreator tree) {

		ResultSet rs = null;
		Connection conn = null;
		try {

			// clear existing beans.
			// could have an issue with object dependent on these beans?
			tree.clearBean();
			Database db = tree.getDatabase();
			Class.forName(db.getDriver());
			conn = DriverManager.getConnection(db.getUrl(), db.getUser(), db.getPassword());
			DatabaseMetaData dmd = conn.getMetaData();
			String[] tabletypes = { "TABLE" };
			// rs = dmd.getTables(dbName, "maritime", "%", tabletypes);
			rs = dmd.getTables(dbName, "PORTAL", "%", tabletypes);
			while (rs.next()) {
				if (rs.getString(4).equalsIgnoreCase("table")) {
					System.out.println("Importing table " + rs.getString(3));
					tree.addBean(getTableDescription(dmd, rs.getString(3), "sss"));
				}
			}
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			close(rs);
			close(conn);
		}

	}

	private Strutscreator getDefaultTree() {
		Strutscreator tree = new Strutscreator();
		Property prop = new Property();
		try {
			PropertyMgr propMgr = new PropertyMgr(Util.prop_file);
			Properties p = propMgr.getProperties();

			prop.setAuthor(p.getProperty("author"));
			prop.setCompany(p.getProperty("company"));
			prop.setName(p.getProperty("applicationname"));
			prop.setVersion(p.getProperty("version"));
			tree.setProperty(prop);

			Database db = new Database();
			db.setMaximumConnections(Integer.parseInt(p.getProperty("jdbc.maximumconnections")));
			db.setMinimumConnections(Integer.parseInt(p.getProperty("jdbc.minimumconnections")));
			db.setJndi(p.getProperty("jdbc.jndi"));
			tree.setDatabase(db);

			Build build = new Build();
			build.setCompiler(p.getProperty("compiler"));
			build.setDateFormat(p.getProperty("dateformat"));

			build.setModuleName(this.getModuleName());
			// build.setDirectory(this.getSrcOutPath());
			build.setDirectory(p.getProperty("proj.outpath"));
			build.setPackage(this.getPackageName());
			build.setWarFileName(this.getWarName());
			build.setServletContainerName(p.getProperty("container.name"));
			build.setServletContainerDir(p.getProperty("servlet.container.dir"));
			tree.setBuild(build);
		} catch (Exception ex) {

		}
		return tree;
	}

	private Bean getTableDescription(DatabaseMetaData dmd, String tableName, String moduleName) {
		ResultSet rs = null;
		Bean bean = new Bean();
		try {
			if ("oracle".equalsIgnoreCase(this.dbms)){
				bean.setTitle(this.getOracleTableComments(tableName));
			}
			bean.setName(util.firstUpper(util.sql2javaName(tableName, 1)).substring(moduleName.length()));
			if (!tableName.equals(util.java2sqlName(bean.getName()))) {
				bean.setSqlName(tableName.toUpperCase());
			}			
			bean.setGenerateDao(true);
			bean.setGenerateProcess(false);
			if ("mssql".equalsIgnoreCase(this.dbms)){
				rs = dmd.getPrimaryKeys(null, null, tableName);
			}else{
				rs = dmd.getPrimaryKeys(dbName, schemaName, tableName);
			}
			HashMap pkMap = new HashMap();
			while (rs.next()) {
				pkMap.put(util.sql2javaName(rs.getString(4), 0), "");
			}
			if (pkMap.size() == 0) {
				System.out.println("err pk able:" + tableName);
			}
			close(rs);
			if ("mssql".equalsIgnoreCase(this.dbms)){
				rs = dmd.getColumns(null, null, tableName, "%");
			}else{
				rs = dmd.getColumns(dbName, schemaName, tableName, "%");
			}
			Attribute attr = new Attribute();
			PrimaryKey pk = new PrimaryKey();
			while (rs.next()) {
				int colType = rs.getInt(5);
				if (colType != Types.BINARY && colType != Types.VARBINARY && colType != Types.LONGVARBINARY) {
					String sqlColName = rs.getString(4);
					String javaColName = util.sql2javaName(sqlColName, 0);
					int colTypeLength = rs.getInt(7);
					int decimalLength = rs.getInt(9);
					Column col = new Column();
					Validation val = new Validation();
					col.setValidation(val);
					col.setName(javaColName);
					if (!util.java2sqlName(javaColName).equals(sqlColName)) {
						col.setSqlName(sqlColName);
					}
					String tit ="";
					if ("oracle".equalsIgnoreCase(this.dbms)){
						tit=getOracleColumnComments(tableName,sqlColName);						
					}else{
						 tit = rs.getString(12);						
					}
					if ("".equalsIgnoreCase(tit) || tit == null) {
						col.setTitle(javaColName);
					} else {
						col.setTitle(tit);
					}
					col.setType(convert(colType, colTypeLength, decimalLength));
					if (!pkMap.containsKey(javaColName)) {
						val.setRequired(false);
						attr.addColumn(col);
					} else {
						pk.addColumn(col);
						val.setRequired(true);
					}

					if (col.getType().equals("string")) {
						try {
							val.setMaxLength(rs.getInt(7));
						} catch (RuntimeException e) {
							val.setMaxLength(30);
						}
					}
				}
				bean.setAttribute(attr);
				bean.setPrimaryKey(pk);
			}
		} catch (SQLException e) {
		} finally {
			close(rs);
		}
		return bean;
	}

	/**
	 * Close ResultSet.
	 * 
	 * @param rs
	 */
	protected void close(ResultSet rs) {
		if (rs != null) {
			try {
				rs.close();
			} catch (SQLException e) {
			}
			rs = null;
		}
	}

	/**
	 * Close Connection.
	 * 
	 * @param conn
	 */
	protected void close(Connection conn) {
		if (conn != null) {
			try {
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			conn = null;
		}
	}

	/*
	 * public String getWebAppsOutPath() { return webAppsOutPath; }
	 * 
	 * public void setWebAppsOutPath(String webAppsOutPath) {
	 * this.webAppsOutPath = webAppsOutPath; }
	 */

	public String getOutPath() {
		return outPath;
	}

	public void setOutPath(String outPath) {
		this.outPath = outPath;
	}
}

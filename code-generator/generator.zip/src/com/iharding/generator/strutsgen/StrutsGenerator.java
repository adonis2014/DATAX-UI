
package com.iharding.generator.strutsgen;

import java.io.File;
import java.util.PropertyResourceBundle;
import java.util.ResourceBundle;

import org.apache.velocity.VelocityContext;

import com.iharding.generator.Generator;
import com.iharding.generator.xml.Bean;
import com.iharding.generator.xml.Column;
import com.iharding.generator.xml.Page;
import com.iharding.generator.xml.Query;
import com.iharding.generator.xml.Strutscreator;
import com.iharding.generator.xml.XMLHandler;
import com.iharding.generator.xml.XMLHandlerImpl;

/**
 * @author     roel
 * @version    1.1.2
 */
public class StrutsGenerator
    extends Generator {

  protected final static String TEMPLATE_DIR = "template/";
  protected final static String LAYOUT_DIR = "layout";
  protected final static String XSLT_FILE = "xslt/html.xsl";
  private String strPackage;
  private String strModule;
  private String daoType;
  
  public static String outPath;

  private String srcTemplatePath;
  private String webTemplatePath;
  
  public void setFrameworkName(String frameworkName) {
    this.setSrcTemplatePath(frameworkName + "/src");
    this.setWebTemplatePath(frameworkName + "/webroot");
  }

  public void setDaoType(String daoType) {
    this.daoType = daoType;
  }

  public static void main(String[] args) throws Exception {

    long start = System.currentTimeMillis();
    XMLHandler handler = new XMLHandlerImpl();

    ResourceBundle prop = PropertyResourceBundle.getBundle(Util.bundle_file);
    int minId=0;int maxId=10;

    try{
    String moduleId=prop.getString("module.index");
    if (moduleId!=null && !"".equalsIgnoreCase(moduleId)){
    	minId=Integer.parseInt(moduleId);
    	maxId=minId+1;
    }
    }catch (Exception ex){
    	ex.printStackTrace();
    }
    
    for(int i=minId;i<maxId;i++){
    	Strutscreator app = handler.load(prop.getString("template.outpath."+i));
    	StrutsGenerator gen = createStrutsGenerator();
    	gen.setLayoutDir(prop.getString("layout.dir"));
    	gen.setTemplateDir(prop.getString("template.dir"));
    	gen.setXsltFile(prop.getString("xslt.file"));
    	gen.setFrameworkName(prop.getString("framework.name"));
    	gen.setDaoType(prop.getString("dao.type"));
    	gen.generateFiles(app);    
    	System.out.println("db reverse module:"+prop.getString("module.name."+i));
    	long end = System.currentTimeMillis();
    	System.out.print( (double) (end - start) / 1000);
    	System.out.println(" seconds");
    	java.text.DecimalFormat f = new java.text.DecimalFormat("#,###");
    	System.out.println(
        f.format(gen.getGeneratedByteCount() / 1024) + " KB generated");
    }
  }

  public void generateFiles(Strutscreator tree) throws Exception {

    super.generateFiles(tree);

    strPackage = tree.getBuild().getPackage();
    strModule = tree.getBuild().getModuleName();
   // copyDirectoryLayout();
   // createDefaultDir();

    generateAppFiles(tree);
    Bean[] beans = tree.getBean();
    for (int i = 0; i < beans.length; i++) {
     //generateHtml(beans[i]);
      //todo need to tap in here for non static beans.
      generateObject(beans[i]);
      generateView(beans[i]);
     generateService(beans[i]);
    generateWebAction(beans[i]);
      generateWebModules(beans[i]);
   //   generateJSP(beans[i]);
    }
  }

  protected String getPath(String strPackage) {
    String path = outputdir;

    if (strPackage != null && strPackage.compareTo("") != 0) {
      String myPackage = strPackage;
      myPackage = myPackage.replace('.', File.separatorChar);
      File directory = new File(path + myPackage);
      directory.mkdirs();
      path += myPackage;
      path = path.concat(File.separator);
    }

    return path;
  }

  protected void createDefaultDir() {
//    File directory = new File(outputdir + "src" + File.separator + "resources");
//    directory.mkdirs();
//    directory = new File(outputdir + "sql");
//    directory.mkdirs();
  }

  private void generateAppFiles(Strutscreator tree) {
    /*  App files are files that are global or apply to app beans */

    String s = File.separator;
    String fileName = "";
    String htmlDir = outputdir  + s;

    VelocityContext context = new VelocityContext(strutsContext);
    String packageName=tree.getBuild().getPackage();
		fileName = htmlDir +  "src/dao/applicationContext-"+packageName.substring(packageName.lastIndexOf(".")+1)+"-dao.xml";
		context = new VelocityContext(strutsContext);
		context.put("beans", tree.getBean());
		applyTemplate(context, fileName, srcTemplatePath +"/dao/spring-dao-xml.vm");
    
		fileName = htmlDir +  "src/service/applicationContext-"+packageName.substring(packageName.lastIndexOf(".")+1)+"-service.xml";
		applyTemplate(context, fileName, srcTemplatePath +"/service/spring-service-xml.vm");
     
		fileName = htmlDir +  "src/web/"+packageName.substring(packageName.lastIndexOf(".")+1)+"-resource_zh_CN.properties";
		applyTemplate(context, fileName, srcTemplatePath +"/web/resource.vm");
		
		fileName = htmlDir +  "src/conf/struts-"+packageName.substring(packageName.lastIndexOf(".")+1)+".xml";
		applyTemplate(context, fileName, srcTemplatePath +"/web/struts-config.vm");
		
		fileName = htmlDir +  "src/conf/applicationContext-struts-"+packageName.substring(packageName.lastIndexOf(".")+1)+".xml";
		applyTemplate(context, fileName, srcTemplatePath +"/web/spring-struts2-xml.vm");
  }

  private void generateView(Bean bean) {
	    String fileName = getPath("src.dao."+strPackage + ".model") + bean.getName() + ".java";

	    VelocityContext context = new VelocityContext(strutsContext);
	    context.put("bean", bean);

	    applyTemplate(context, fileName, srcTemplatePath + "/dao/model.vm");

	    if (bean.getGenerateDao()) {
	      fileName = getPath("src.dao."+strPackage + ".dao") + bean.getName() + "BaseDAO.java";
	      applyTemplate(context, fileName, srcTemplatePath + "/dao/base-dao-interface.vm");
	      fileName = getPath("src.dao."+strPackage + ".dao") + bean.getName() + "DAO.java";
	      File codeFile=new File(fileName);
	      if (!codeFile.exists()){
	        applyTemplate(context, fileName,srcTemplatePath + "/dao/dao-interface.vm");
	      }
	      fileName = getPath("src.dao."+strPackage + ".dao."+this.daoType) + bean.getName() + "BaseDAO"+util.firstUpper(daoType)+".java";
	      applyTemplate(context, fileName, srcTemplatePath + "/dao/dao-abstract.vm");
	      fileName = getPath("src.dao."+strPackage + ".dao."+this.daoType) + bean.getName() + "DAO"+util.firstUpper(daoType)+".java";
	      codeFile=new File(fileName);
	      if (!codeFile.exists()){
	        applyTemplate(context, fileName, srcTemplatePath + "/dao/dao.vm");
	      }
	    }


	  }
  
  private void generateObject(Bean bean) {
    String fileName = getPath("src.dao."+strPackage + ".model") + bean.getName() + ".java";

    VelocityContext context = new VelocityContext(strutsContext);
    context.put("bean", bean);

    applyTemplate(context, fileName, srcTemplatePath + "/dao/model.vm");

    if (bean.getGenerateDao()) {
      fileName = getPath("src.dao."+strPackage + ".dao") + bean.getName() + "BaseDAO.java";
      applyTemplate(context, fileName, srcTemplatePath + "/dao/base-dao-interface.vm");
      fileName = getPath("src.dao."+strPackage + ".dao") + bean.getName() + "DAO.java";
      File codeFile=new File(fileName);
      if (!codeFile.exists()){
        applyTemplate(context, fileName,srcTemplatePath + "/dao/dao-interface.vm");
      }
      fileName = getPath("src.dao."+strPackage + ".dao."+this.daoType) + bean.getName() + "BaseDAO"+util.firstUpper(daoType)+".java";
      applyTemplate(context, fileName, srcTemplatePath + "/dao/dao-abstract.vm");
      fileName = getPath("src.dao."+strPackage + ".dao."+this.daoType) + bean.getName() + "DAO"+util.firstUpper(daoType)+".java";
      codeFile=new File(fileName);
      if (!codeFile.exists()){
        applyTemplate(context, fileName, srcTemplatePath + "/dao/dao.vm");
      }
    }

//    if(bean.getGenerateDao() || bean.getGenerateProcess()) {
//
//      fileName =
//        getPath(strPackage + ".controller") + bean.getName() + "Form.java";
//      applyTemplate(context, fileName, "struts-form.vm");
//
//
//      fileName =
//        getPath(strPackage + ".controller") + bean.getName() + "Action.java";
//      applyTemplate(context, fileName, "struts-action.vm");
//    }
  }

  private void generateService(Bean bean) {
	    
	  
    String fileName;

    VelocityContext context = new VelocityContext(strutsContext);
    context.put("bean", bean);

        
	  //VelocityContext context = new VelocityContext(strutsContext);
	  /*String fileName = getPath("src."+strPackage + ".model") + bean.getName() + ".java";

	    VelocityContext context = new VelocityContext(strutsContext);
	    context.put("bean", bean);

	    applyTemplate(context, fileName, frameworkName + "/model.vm");*/

	    if (bean.getGenerateDao()) {
	      fileName = getPath("src.service."+strPackage + ".service.impl") + bean.getName() + "ManagerImpl.java";
	      File codeFile=new File(fileName);
	      if (!codeFile.exists()){
	    	  applyTemplate(context, fileName, srcTemplatePath + "/service/service.vm");
	      }
	      fileName = getPath("src.service."+strPackage + ".service") + bean.getName() + "Manager.java";
	      codeFile=new File(fileName);
	      if (!codeFile.exists()){
	        applyTemplate(context, fileName,srcTemplatePath + "/service/service-interface.vm");
	      }
	    }

	  }
  
  private void generateWebAction(Bean bean) {
	    
	  String fileName;
	  VelocityContext context = new VelocityContext(strutsContext);
	  context.put("bean", bean);
	  
	  /*String fileName = getPath("src."+strPackage + ".model") + bean.getName() + ".java";

	    VelocityContext context = new VelocityContext(strutsContext);
	    context.put("bean", bean);

	    applyTemplate(context, fileName, frameworkName + "/model.vm");*/

	    if (bean.getGenerateDao()) {
	      fileName = getPath("src.web."+strPackage + ".action") + bean.getName() + "MgntAction.java";
	      File codeFile=new File(fileName);
	      if (!codeFile.exists()){
	      applyTemplate(context, fileName, srcTemplatePath + "/web/action.vm");
	      }
	      fileName = getPath("src.web."+strPackage + ".dwr") + bean.getName() + "DwrAction.java";
	      codeFile=new File(fileName);
	      if (!codeFile.exists()){
	        applyTemplate(context, fileName,srcTemplatePath + "/web/dwr-action.vm");
	      }
	      fileName = getPath("src.web."+strPackage + ".wrapper");
	      new File(fileName).mkdirs();
	    }

  }  
  
  private void generateWebModules(Bean bean) {
	    
	  String fileName;
	  VelocityContext context = new VelocityContext(strutsContext);
	  context.put("bean", bean);
	  /*String fileName = getPath("src."+strPackage + ".model") + bean.getName() + ".java";

	    VelocityContext context = new VelocityContext(strutsContext);
	    context.put("bean", bean);

	    applyTemplate(context, fileName, frameworkName + "/model.vm");*/

	    if (bean.getGenerateDao()) {
		fileName = getPath("webroot.modules."+strModule + "." + bean.getName()) + "show.jsp";
		applyTemplate(context, fileName,webTemplatePath + "/modules/show.vm");
		  fileName = getPath("webroot.modules."+strModule + "." + bean.getName()) + "add.jsp";
		  applyTemplate(context, fileName, webTemplatePath + "/modules/add.vm");
		  fileName = getPath("webroot.modules."+strModule + "." + bean.getName()) + "edit.jsp";
		  applyTemplate(context, fileName,webTemplatePath + "/modules/edit.vm");
		  fileName = getPath("webroot.modules."+strModule + "." + bean.getName()) + "view.jsp";
		  applyTemplate(context, fileName,webTemplatePath + "/modules/view.vm");
		  fileName = getPath("webroot.modules."+strModule + "." + bean.getName()) + "query.jsp";
		  applyTemplate(context, fileName,webTemplatePath + "/modules/query.vm");

	    }

  }  
  
  private void generateHtml(Bean bean) {
    if (! (bean.getGenerateDao() || bean.getGenerateProcess())) {
      return;
    }

    String htmlDir = outputdir + "webroot" + File.separator + "manager"
        + File.separator + bean.getName() + File.separator;
    File f = new File(htmlDir);
    f.mkdirs();

    VelocityContext context = new VelocityContext(strutsContext);
    context.put("bean", bean);

    String fileName;

    if (bean.getGenerateDao()) {
      fileName = htmlDir + "entry.jsp";
      applyXsltTemplate(context, fileName, "web/entry.vm");

      fileName = htmlDir + "summary.jsp";
      applyXsltTemplate(context, fileName, "web/summary.vm");

      fileName = htmlDir + "view.jsp";
      applyXsltTemplate(context, fileName, "web/view.vm");

      fileName = htmlDir + "remove.jsp";
      applyXsltTemplate(context, fileName, "web/remove.vm");

      htmlDir = outputdir + "webroot" + File.separator + "query"
          + File.separator + bean.getName() + File.separator;

      f = new File(htmlDir);
      f.mkdirs();

      Column[] fields = bean.getPrimaryKey().getColumn();
      context = new VelocityContext(strutsContext);
      context.put("beanName", bean.getName());
      context.put("processName", "view");
      context.put("actionName", "/" + bean.getName() + "/view");
      context.put("pageTitle", "SearchByPK");
      context.put("isQuery", "true");
      context.put("singlePage", "true");
      context.put("pageFields", fields);
      context.put("successPath", "1");
      context.put("cancelPath", "1");
      fileName = htmlDir + "SearchByPK.jsp";
      applyXsltTemplate(context, fileName, "web/process.vm");

      Query[] query = bean.getQuery();
      for (int i = 0; i < query.length; i++) {
        fields = util.getQueryVariableColumnList(bean, query[i]);
        if (fields != null) {
          context = new VelocityContext(strutsContext);
          context.put("beanName", bean.getName());
          context.put("processName", query[i].getName());
          context.put("actionName",
                      "/" + bean.getName() + "/" + query[i].getName());
          context.put("pageTitle", query[i].getName());
          context.put("isQuery", "true");
          context.put("singlePage", "true");
          context.put("pageFields", fields);
          context.put("cancelPath", "1");
          fileName = htmlDir + query[i].getName() + ".jsp";
          applyXsltTemplate(context, fileName, "web/process.vm");
        }
      }
    }

    if (bean.getGenerateProcess()) {
      com.iharding.generator.xml.Process[] processes =
          bean.getProcess();
      if (processes.length > 0) {
        htmlDir = outputdir + "webroot" + File.separator + "process" +
            File.separator
            + bean.getName() + File.separator;
        f = new File(htmlDir);
        f.mkdirs();
      }
      for (int i = 0; i < processes.length; i++) {
        Page[] pages = processes[i].getPage();
        if (pages.length == 1) {
          context = new VelocityContext(strutsContext);
          context.put("beanName", bean.getName());
          context.put("processName",
                      "/" + bean.getName() + "/" + processes[i].getName());
          context.put("pageTitle", pages[0].getTitle());
          context.put("forwards", pages[0].getForward());
          context.put("actionName",
                      "/" + bean.getName() + "/" + processes[i].getName());
          context.put("singlePage", "true");
          context.put("pageFields", util.getProcessPageFieldList(bean, pages[0]));

          // for existance indication only
          context.put("successPath", "1");
          context.put("cancelPath", processes[i].getCancelPath());
          fileName = htmlDir + processes[i].getName() + ".jsp";
          applyXsltTemplate(context, fileName, "web/process.vm");
        }
        else {
          for (int j = 0; j < pages.length; j++) {
            context = new VelocityContext(strutsContext);
            context.put("beanName", bean.getName());
            context.put("pageNumber", new Integer(j + 1));
            context.put("processName", processes[i].getName());
            context.put("actionName",
                        "/" + bean.getName() + "/" + processes[i].getName() +
                        (j + 1));
            context.put("pageTitle", pages[j].getTitle());
            context.put("forwards", pages[j].getForward());
            context.put("pageFields",
                        util.getProcessPageFieldList(bean, pages[j]));
            if (j == pages.length - 1) {
              context.put("successPath", "1");
            }
            else {
              context.put("continuePath", "1");
            }
            context.put("cancelPath", processes[i].getCancelPath());
            if (j > 0) {
              context.put("backPath", "1");
            }
            fileName = htmlDir + processes[i].getName() + (j + 1) + ".jsp";
            applyXsltTemplate(context, fileName, "web/process.vm");
          }
        }
        if (processes[i].getSuccessPath() == null) {
          fileName = htmlDir + processes[i].getName() + "Finish.jsp";
          applyXsltTemplate(context, fileName, "web/process-finish.vm");
        }
      }
    }
  }

  private void generateHtmlMenu(Strutscreator tree) {
    String htmlDir = outputdir + "webroot" + File.separator;

    VelocityContext context = new VelocityContext(strutsContext);
    context.put("menu", tree.getMenu());

    String fileName = htmlDir + "template" + File.separator + "menu.jsp";
    applyXsltTemplate(context, fileName, "web/menu.vm");
  }

  public static StrutsGenerator createStrutsGenerator() {
    return new StrutsGenerator();
  }

public String getSrcTemplatePath() {
	return srcTemplatePath;
}

public void setSrcTemplatePath(String srcTemplatePath) {
	this.srcTemplatePath = srcTemplatePath;
}

public String getWebTemplatePath() {
	return webTemplatePath;
}

public void setWebTemplatePath(String webTemplatePath) {
	this.webTemplatePath = webTemplatePath;
}



}

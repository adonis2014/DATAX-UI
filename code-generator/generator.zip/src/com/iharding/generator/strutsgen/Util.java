package com.iharding.generator.strutsgen;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Properties;

import org.apache.velocity.util.StringUtils;

import com.iharding.generator.xml.Attribute;
import com.iharding.generator.xml.Bean;
import com.iharding.generator.xml.Choice;
import com.iharding.generator.xml.Column;
import com.iharding.generator.xml.Condition;
import com.iharding.generator.xml.GlobalValueRef;
import com.iharding.generator.xml.Page;
import com.iharding.generator.xml.Query;
import com.iharding.generator.xml.Validation;
import com.iharding.generator.xml.Value;

/**
 * @author     roel
 * @version    1.1.2
 *
 */
public class Util
    extends StringUtils {
	

	public static String prop_file="StrutsCreator-his.properties";
	public static String bundle_file="StrutsCreator-his";

  HashMap sqlTypeMap;
  HashMap javaTypeMap;
  HashMap javaSqlTypeMap;
  HashMap refs;

  private String dbms;
  private String dateFormat = "dd/MM/yyyy";

  /**
   * Set date format.
   * @param dateFormat
   */
  public void setDateFormat(String dateFormat) {
    this.dateFormat = dateFormat;
  }

  /**
   * Default constructor
   */
  public Util() {
    javaTypeMap = new HashMap();
    javaTypeMap.put("string", "String");
    javaTypeMap.put("auto", "Long");
    javaTypeMap.put("long", "Long");
    javaTypeMap.put("double", "Double");
    javaTypeMap.put("float", "Float");
    javaTypeMap.put("boolean", "Boolean");
    javaTypeMap.put("password", "String");
    javaTypeMap.put("email", "String");
    javaTypeMap.put("creditcard", "String");
    javaTypeMap.put("date", "Timestamp");
    javaTypeMap.put("timestamp", "Timestamp");
  }

  /**
   * Set GlobalValueReference
   * @param refsArray
   */
  public void setGlobalValueRef(GlobalValueRef[] refsArray) {
    refs = new HashMap();
    for (int i = 0; i < refsArray.length; i++) {
      refs.put(refsArray[i].getName(), refsArray[i].getChoice());
    }
  }

  /**
   * Return globalValueChoice
   * @param name
   * @return
   */
  public Choice[] getGlobalValueChoice(String name) {
    return (Choice[]) refs.get(name);
  }

  /**
   *  set SQL type mapping for certain DBMS.
   *
   * @param  dbms
   * @exception  Exception
   */
  public void setDbms(String dbms) throws Exception {
    this.dbms = dbms;
    PropertyMgr prop = new PropertyMgr("SQLType.properties");
    Properties p = prop.getProperties();
    sqlTypeMap = new HashMap();
    sqlTypeMap.put("int", p.getProperty(dbms + ".type.int"));
    sqlTypeMap.put("long", p.getProperty(dbms + ".type.long"));
    sqlTypeMap.put("float", p.getProperty(dbms + ".type.float"));
    sqlTypeMap.put("double", p.getProperty(dbms + ".type.double"));
    sqlTypeMap.put("boolean", p.getProperty(dbms + ".type.boolean"));
    sqlTypeMap.put("char", p.getProperty(dbms + ".type.char"));
    sqlTypeMap.put("byte", p.getProperty(dbms + ".type.byte"));
    sqlTypeMap.put("short", p.getProperty(dbms + ".type.short"));
    sqlTypeMap.put("string", p.getProperty(dbms + ".type.string"));
    sqlTypeMap.put("auto", p.getProperty(dbms + ".type.auto"));
    sqlTypeMap.put("date", p.getProperty(dbms + ".type.date"));
    sqlTypeMap.put("timestamp", p.getProperty(dbms + ".type.timestamp"));
    sqlTypeMap.put("memo", p.getProperty(dbms + ".type.memo"));
    sqlTypeMap.put("email", p.getProperty(dbms + ".type.email"));
    sqlTypeMap.put("creditcard", p.getProperty(dbms + ".type.creditcard"));
    javaSqlTypeMap = new HashMap();
    javaSqlTypeMap.put("int", p.getProperty("type.int"));
    javaSqlTypeMap.put("long", p.getProperty("type.long"));
    javaSqlTypeMap.put("float", p.getProperty("type.float"));
    javaSqlTypeMap.put("double", p.getProperty("type.double"));
    javaSqlTypeMap.put("boolean", p.getProperty("type.boolean"));
    javaSqlTypeMap.put("char", p.getProperty("type.char"));
    javaSqlTypeMap.put("byte", p.getProperty("type.byte"));
    javaSqlTypeMap.put("short", p.getProperty("type.short"));
    javaSqlTypeMap.put("string", p.getProperty("type.string"));
    javaSqlTypeMap.put("auto", p.getProperty("type.auto"));
    javaSqlTypeMap.put("date", p.getProperty("type.date"));
    javaSqlTypeMap.put("timestamp", p.getProperty("type.timestamp"));
    javaSqlTypeMap.put("memo", p.getProperty("type.memo"));
    javaSqlTypeMap.put("email", p.getProperty("type.email"));
    javaSqlTypeMap.put("creditcard", p.getProperty("type.creditcard"));
  }

  /**
   * Specify if the type is number type group.
   * @param type
   * @return
   */
  public boolean isNumberType(String type) {
    if ("int".equals(type) || "long".equals(type) || "float".equals(type)
        || "double".equals(type) || "short".equals(type) || "auto".equals(type)) {
      return true;
    }
    else {
      return false;
    }
  }

  public boolean isHaveAuto(Bean bean) {
    try {
      Column f = bean.getPrimaryKey().getColumn(0);
      if (f.getType().equals("auto")) {
        return true;
      }
      else {
        return false;
      }
    }
    catch (Exception e) {
      return false;
    }

  }
  
  public boolean isHaveDate(Bean bean) {
	    try {
	      Column f = bean.getPrimaryKey().getColumn(0);
	      if (f.getType().equals("date")) {
	        return true;
	      }
	      else {
	        return false;
	      }
	    }
	    catch (Exception e) {
	      return false;
	    }

	  }
  
  public boolean isHaveLob(Bean bean) {
	  Column[] columns=bean.getAttribute().getColumn();
	  String type="";
	  for(int i=0;i<columns.length;i++){
		  type=columns[i].getType();
		  if (type.equals("clob")||type.equalsIgnoreCase("memo")||type.equalsIgnoreCase("blob")){
			  return true;
		  }
	  }
	        return false;	 
	  }

  /**
   * Check if type is String type.
   * @param type
   * @return
   */
  public boolean isStringType(String type) {
    if ("string".equals(type) || "password".equals(type) || "email".equals(type) ||
        "creditcard".equals(type)) {
      return true;
    }
    else {
      return false;
    }
  }

  /**
   * Check if type is date type.
   * @param type
   * @return
   */
  public boolean isDateType(String type) {
    if ("date".equals(type) || "timestamp".equals(type)) {
      return true;
    }
    else {
      return false;
    }
  }

  /**
   *  Get union of PrimaryKey's columns and Attribute's columns. Primary key
   * columns last, because will be used much by SQL operation
   *
   *@param  bean  Description of Parameter
   *@return       The allColumns value
   */
  public Column[] getAllColumns(Bean bean) {
    Column[] pks = bean.getPrimaryKey().getColumn();
    Attribute attr = bean.getAttribute();
    if (attr != null) {
      Column[] ats = attr.getColumn();
      Column[] uni = new Column[pks.length + ats.length];
      System.arraycopy(ats, 0, uni, 0, ats.length);
      System.arraycopy(pks, 0, uni, ats.length, pks.length);
      return uni;
    }
    else {
      return pks;
    }
  }

  /**
   *  Get union of PrimaryKey's columns and Attribute's columns.
   *
   *@param  bean  Description of Parameter
   *@return       The allColumns value
   */
  public Column[] getAllColumnsPKFirst(Bean bean) {
    Column[] pks = bean.getPrimaryKey().getColumn();
    Attribute attr = bean.getAttribute();
    if (attr != null) {
      Column[] ats = attr.getColumn();
      Column[] uni = new Column[pks.length + ats.length];
      System.arraycopy(pks, 0, uni, 0, pks.length);
      System.arraycopy(ats, 0, uni, pks.length, ats.length);
      return uni;
    }
    else {
      return pks;
    }
  }

  /**
   *  Get union of PrimaryKey's columns and Attribute's columns with column with
   *  type auto excluded. Assumed that primary key that has auto type is the
   *  only primary key column
   *
   *@param  bean  Description of Parameter
   *@return       The allColumnsNoAuto value
   */
  public Column[] getAllColumnsNoAuto(Bean bean) {
    Column[] pks = bean.getPrimaryKey().getColumn();
    Attribute attr = bean.getAttribute();
    Column[] ats = null;
    Column[] temp;

    if (attr != null) {
      ats = attr.getColumn();
      temp = new Column[pks.length + ats.length];
    }
    else {
      temp = new Column[pks.length];
    }

    int index = 0;
    for (int i = 0; i < pks.length; i++) {
      if (!pks[i].getType().equals("auto")) {
        temp[index++] = pks[i];
      }
    }

    if (ats != null) {
      for (int i = 0; i < ats.length; i++) {
        temp[index++] = ats[i];
      }
    }

    Column[] uni = new Column[index];
    System.arraycopy(temp, 0, uni, 0, index);
    return uni;
  }

  /**
   *  convert capital in text to _ and lowercase, but the first letter e.g.
   *  firstName become first_name
   *
   *@param  name  Description of Parameter
   *@return       Description of the Returned Value
   */
  public String java2sqlName(String name) {
    String column = "";
    for (int i = 0; i < name.length(); i++) {
      if (i < name.length() - 1 &&
          (name.charAt(i) >= 'a' && name.charAt(i) <= 'z') &&
          (name.charAt(i + 1) >= 'A' && name.charAt(i + 1) <= 'Z')) {
        column += name.charAt(i) + "_";
      }
      else {
        column += name.charAt(i);
      }
    }
    return column.toLowerCase();
  }

  /**
   * Convert sql field naming (field_name) to java field naming (fieldName).
   * @param name
   * @return
   */
  public String sql2javaName(String name) {
    String column = "";
    for (int i = 0; i < name.length(); i++) {
      if (name.charAt(i) == '_') {
        column += ++i < name.length() ?
            String.valueOf(name.charAt(i)).toUpperCase() : "";
      }
      else {
        column += name.charAt(i);
      }
    }
    return column;
  }
  
  public String getBasePackage(String packageStr){
	  int id1=packageStr.indexOf(".");
	  int id2=packageStr.indexOf(".",id1+1);
//	  int id3=packageStr.indexOf(".",id2+1);
	  return packageStr.substring(0,id2);
  }

  public String sql2javaName(String name, int isTable) {
    String column = "";
    boolean needUpperCase = false;
    //��ȡǰ׺
//    if (isTable == 1) {
//      name = name.substring(name.indexOf("_") + 1);
//    }
    for (int i = 0; i < name.length(); i++) {
      if (name.charAt(i) == '_') {
        column += ++i < name.length() ?
            String.valueOf(name.charAt(i)).toUpperCase() : "";
        needUpperCase = true;
      }
      else {
        if (i == 0 && isTable == 1) {
          column += String.valueOf(name.charAt(i)).toUpperCase();
          needUpperCase = false;
        }
        else {
          column += String.valueOf(name.charAt(i)).toLowerCase();
        }
      }
    }
    return column;
  }

  /**
   * Get all query condition that it's field-value is "?".
   * @param bean
   * @param query
   * @return
   */
  public Column[] getQueryVariableColumnList(Bean bean, Query query) {
    Column[] cols = getAllColumns(bean);
    Condition[] cond = query.getCondition();
    Column[] temp = new Column[cond.length];
    int index = 0;
    for (int i = 0; i < cond.length; i++) {
      if (cond[i].getFieldCondition().indexOf("?") > 0) {
        Column col = findColumnByName(cond[i].getFieldName(), cols);
        if (col != null) {
          temp[index++] = col;
        }
      }
    }

    if (index > 0) {
      Column[] vars = new Column[index];
      System.arraycopy(temp, 0, vars, 0, index);
      return vars;
    }
    else {
      return null;
    }
  }

  /**
   * Get list of field used by a process.
   * @param bean
   * @param page
   * @return
   */
  public Column[] getProcessPageFieldList(Bean bean, Page page) {
    Column[] cols = getAllColumns(bean);
    Column[] temp = new Column[page.getFieldNameCount()];
    String[] fieldNames = page.getFieldName();
    for (int i = 0; i < fieldNames.length; i++) {
      Column col = findColumnByName(fieldNames[i], cols);
      temp[i] = col;
    }
    return temp;
  }

  /**
   * Find a column from a list of column.
   * @param colName
   * @param columnListReference
   * @return
   */
  private Column findColumnByName(String colName, Column[] columnListReference) {
    for (int i = 0; i < columnListReference.length; i++) {
      if (columnListReference[i].getName().equals(colName)) {
        return columnListReference[i];
      }
    }
    return null;
  }

  /**
   *
   * @param column
   * @return
   */
  public String sqlType(Column column) {
    boolean required;
    Validation val = column.getValidation();
    if (val != null) {
      required = val.getRequired();
    }
    else {
      required = false;
    }
    return sqlType(column.getType(), required,
                   column.getValidation().getMaxLength());
  }

  public String javaSqlType(Column column) {
    String type = column.getType();
    String sqlType;
    if (javaSqlTypeMap.containsKey(type)) {
      sqlType = (String) javaSqlTypeMap.get(type);
    }
    else if ("password".equalsIgnoreCase(type)) {
      sqlType = (String) javaSqlTypeMap.get("string");
    }
    else {
      sqlType = "UNKNOWN";
    }
    return sqlType;
  }

  /**
   *  Java type mapping.
   *
   *@param  type  Description of Parameter
   *@return       Description of the Returned Value
   */
  public String javaType(String type) {
    if (javaTypeMap.containsKey(type)) {
      return (String) javaTypeMap.get(type);
    }
    else {
      return type;
    }
  }

  /**
   *  Full Qualified Java type mapping. Almost similar to javaType(),
   *  but return java.util.Date for date type and java.sql.Timestamp
   *  for
   *
   *@param  type  Description of Parameter
   *@return       Description of the Returned Value
   */
  public String fqJavaType(String type) {
    if ("date".equals(type)) {
      return "java.util.Date";
    }
    else if ("timestamp".equals(type)) {
      return "java.sql.Timestamp";
    }else if ("int".equals(type)) {
      return "Integer";
    }else if ("clob".equals(type)) {
      return "String";
    }else if ("memo".equals(type)) {
      return "String";
    }
    else if (javaTypeMap.containsKey(type)) {
      return (String) javaTypeMap.get(type);
    }
    else {
      return type;
    }
  }
  
  public int getMaxLength(int maxLength){
	  if (maxLength % 2==0){
		  return maxLength/2;
	  }else{
		  return maxLength/2+1;
	  }
  }
  
  public String fpJavaType(String type) {
	    if ("date".equals(type)) {
	      return "Date";
	    }
	    else if ("timestamp".equals(type)) {
	      return "Timestamp";
	    }else if ("int".equals(type)) {
	      return "Int";
	    }else if ("clob".equals(type)) {
	      return "String";
	    }else if ("memo".equals(type)) {
	      return "String";
	    }
	    else if (javaTypeMap.containsKey(type)) {
	      return (String) javaTypeMap.get(type);
	    }
	    else {
	      return type;
	    }
	  }

  /**
   *  Attribute with default initial value.
   *
   * @param  type
   * @param  attr
   * @return
   */
  public String initAttr(String type, String attr) {
    if ("int".equals(type) || "long".equals(type) || "short".equals(type)) {
      return type + " " + attr + " = 0";
    }
    else if ("double".equalsIgnoreCase(type)) {
      return type + " " + attr + " = 0.0";
    }
    else if ("float".equalsIgnoreCase(type)) {
      return type + " " + attr + " = (float) 0.0";
    }
    else if ("String".equalsIgnoreCase(type) ||
             "password".equalsIgnoreCase(type)) {
      return "String " + attr + " = \"\"";
    }
    else if ("auto".equalsIgnoreCase(type)) {
      return "long " + attr;
    }
    else {
      return type + " " + attr;
    }
  }

  /**
   *  Generate the code to set an Attribute to the default initial value
   *
   *  @param  type  Description of Parameter
   *  @param  attr  Description of Parameter
   *  @return       Description of the Returned Value
   */
  public String initValue(String type, String attr) {
    if ("int".equals(type) || "long".equals(type) || "short".equals(type)) {
      return attr + " = 0";
    }
    else if ("double".equalsIgnoreCase(type)) {
      return attr + " = 0.0";
    }
    else if ("float".equalsIgnoreCase(type)) {
      return attr + " = (float) 0.0";
    }
    else if ("String".equalsIgnoreCase(type) ||
             "password".equalsIgnoreCase(type)) {
      return attr + " = \"\"";
    }
    else if ("auto".equalsIgnoreCase(type)) {
      return attr + " = 0";
    }
    else {
      return attr;
    }
  }

  public String createDynaFormPropertyTag(Column column) {
    StringBuffer sb = new StringBuffer("<form-property name=\"");
    sb.append(column.getName()).append("\" type=\"");
    if (isStringType(column.getType())) {
      sb.append("java.lang.String\" initial=\"\"/>");
    }
    else if (isNumberType(column.getType())) {
      if ("auto".equals(column.getType())) {
        sb.append("java.lang.Long\"");
      }
      else if ("int".equals(column.getType())) {
        sb.append("java.lang.Integer").append("\"");
      }
      else {
        sb.append("java.lang." + firstUpper(column.getType())).append("\"");
      }
      sb.append(" initial=\"0\"/>");
    }
    else if (isDateType(column.getType())) {
      sb.append("java.lang.String").append("\"/>");
    }
    if ("password".equals(column.getType())) {
      String prop = sb.toString();
      int i = column.getName().length() + 21;
      prop = prop.substring(0, i) + "2" + prop.substring(i);
      return sb.toString() + "\r\n      " + prop;
    }
    else {
      return sb.toString();
    }
  }

  /**
   * Generate request parameter from a column.
   * @param column
   * @return
   */
  public String requestParam(Column column) {
    return requestParam(column.getName(), column.getType());
  }
  
  public String toUpCase(String str){
	  return str.toUpperCase();
  }

  /**
   *  Capitalize first letter.
   *@param  s
   *@return
   */
  public String firstUpper(String s) {
    if (s.length() > 1) {
      return capitalizeFirstLetter(s);
    }
    else {
      return s;
    }
  }

  /**
   *  Lower first letter.
   * @param  s
   * @return
   */
  public String firstLower(String s) {
    if (s.length() > 1) {
      return s.substring(0, 1).toLowerCase() + s.substring(1);
    }
    else {
      return s;
    }
  }

  
  /**
   *  list Primary Key in a bean.
   *
   *@param  bean
   *@return
   */
  public String[] primaryKeyList(Bean bean) {
    Column[] pks = bean.getPrimaryKey().getColumn();
    String[] pklist = new String[pks.length];
    String type = "";
    for (int i = 0; i < pks.length; i++) {
      type = javaType(pks[i].getType());
      if ("int".equalsIgnoreCase(type)) {
        type = "Integer";
      }
      pklist[i] = type + " " + pks[i].getName();
    }
    return pklist;
  }
  
  /**
   *  list Primary Key in a bean.
   *
   *@param  bean
   *@return
   */
  public String[] primaryKeyListWithOutType(Bean bean) {
    Column[] pks = bean.getPrimaryKey().getColumn();
    String[] pklist = new String[pks.length];

    for (int i = 0; i < pks.length; i++) {
    	if ("long".equalsIgnoreCase(pks[i].getType())){
    		 pklist[i] ="Long.valueOf("+ pks[i].getName()+")";
    	}else if ("int".equalsIgnoreCase(pks[i].getType())){
    		 pklist[i] ="Integer.valueOf("+ pks[i].getName()+")";
    	}else{
    		pklist[i] = pks[i].getName();
    	}
    }
    return pklist;
  }
  public String getPrimaryKeyType(Bean bean) {
    Column[] pks = bean.getPrimaryKey().getColumn();
    return javaType(pks[0].getType());
  }

  public String getPrimaryKeyName(Bean bean) {
    Column[] pks = bean.getPrimaryKey().getColumn();
    return pks[0].getName();
  }

  public String getPrimaryKeySetName(Bean bean) {
    Column[] pks = bean.getPrimaryKey().getColumn();
    if (pks.length>0){
    	return this.firstUpper(pks[0].getName());
    }else{
    	return "";
    }
  }
  
  public boolean isHavePrimaryKey(Bean bean) {
	  Column[] pks = bean.getPrimaryKey().getColumn();
	    if (pks.length>0){
	    	return true;
	    }else{
	    	return false;
	    }
	  }

  /**
   *  return array of column name in sql format.
   *
   *@param  columns
   *@return
   */
  public String[] sqlNames(Column[] columns) {
    String[] list = new String[columns.length];
    for (int i = 0; i < columns.length; i++) {
      if (columns[i].getSqlName() == null) {
        list[i] = java2sqlName(columns[i].getName());
      }
      else {
        list[i] = columns[i].getSqlName();
      }
    }
    return list;
  }

  /**
   *  list sql column for UPDATE operation.
   *
   *@param  bean
   *@return
   */
  public String[] sqlSet(Bean bean) {
    Attribute attr = bean.getAttribute();
    if (attr != null) {
      Column[] ats = attr.getColumn();
      String[] list = new String[ats.length];
      for (int i = 0; i < list.length; i++) {
        if (ats[i].getSqlName() == null || "".equals(ats[i].getSqlName())) {
          list[i] = java2sqlName(ats[i].getName()) + "=?";
        }
        else {
          list[i] = ats[i].getSqlName() + "=?";
        }
      }
      return list;
    }
    else {
      return null;
    }
  }

  /**
   *  list primary key column for UPDATE operation.
   *
   *@param  bean
   *@return
   */
  public String[] sqlCond(Bean bean) {
    Column[] pks = bean.getPrimaryKey().getColumn();
    String[] list = new String[pks.length];
    for (int i = 0; i < list.length; i++) {
      if (pks[i].getSqlName() == null || "".equals(pks[i].getSqlName())) {
        list[i] = java2sqlName(pks[i].getName()) + "=?";
      }
      else {
        list[i] = pks[i].getSqlName() + "=?";
      }
    }
    return list;
  }

  /**
   * Get column of type "auto" (if any) from a bean.
   * @param bean
   * @return
   */
  public String getAutoColumn(Bean bean) {
    try {
      Column f = bean.getPrimaryKey().getColumn(0);
      if (f.getType().equals("auto")) {
        return f.getName();
      }
      else {
        return null;
      }
    }
    catch (Exception e) {
      return null;
    }
  }

  /**
   * Return lenght of an array (for used by velocity template).
   * @param array
   * @return array's length
   */
  public int arrLen(java.lang.Object array) {
    return Array.getLength(array);
  }

  /**
   * Get validation dependencies for validation.xml.
   * @param type
   * @param validation
   * @return
   */
  public String getValidationDependencies(String type, Validation validation) {
    if (validation == null) {
      return "";
    }
    ArrayList dep = new ArrayList();
    if (validation.getRequired()) {
      dep.add("required");
    }
    if (isStringType(type)) {
      if ("email".equals(type)) {
        dep.add("email");
      }
      else if ("creditcard".equals(type)) {
        dep.add("creditCard");
      }
      else if (validation.getMask() != null) {
        dep.add("mask");
      }
      else if ("password".equals(type)) {
        dep.add("password");
      }
      if (validation.hasMinLength()) {
        dep.add("minlength");
      }
      dep.add("maxlength");
    }
    else if (isNumberType(type)) {
      if ("int".equals(type)) {
        dep.add("integer");
      }
      else if (!"auto".equals(type)) {
        dep.add(type);
      }
      if (validation.hasMin() || validation.hasMax()) {
        dep.add("range");
      }
    }
    else if ("date".equals(type)) {
      dep.add("date");
    }

    String valdep = "";
    if (dep.size() > 0) {
      for (int i = 0; i < dep.size() - 1; i++) {
        valdep += (String) dep.get(i) + ",";
      }
      valdep += (String) dep.get(dep.size() - 1);
    }
    return valdep;
  }

  /**
   * Render a Column to struts <html:component/>.
   * @param field
   * @param beanName
   * @return
   */
  public String strutsField(Column field, String beanName) {
    String type = field.getType();
    int len = 0;
    if (field.getValidation().hasMaxLength()) {
      len = field.getValidation().getMaxLength();
    }
    else {
      len = 30;
    }
    StringBuffer sf = new StringBuffer("");
    Value vals = field.getValue();
    if (vals != null) {
      String widget = vals.getWidget();
      String globalRefName = vals.getGlobalValueRef();
      if (globalRefName != null) {
        Choice[] cs = (Choice[]) refs.get(vals.getGlobalValueRef());
        if ("select".equals(widget)) {
          sf.append("<html:select property=\"" + field.getName() + "\">\n");
          for (int i = 0; i < cs.length; i++) {
            sf.append("<html:option value=\"" + cs[i].getCode() + "\">");
            sf.append("<bean:message key=\"" + globalRefName + ".");
            sf.append(cs[i].getCode() + "\"/>" + "</html:option>\n");
          }
          sf.append("</html:select>");
        }
        else {
          for (int i = 0; i < cs.length; i++) {
            sf.append("<html:radio property=\"" + field.getName() +
                      "\" value=\"");
            sf.append(cs[i].getCode() + "\"/>" + "<bean:message key=\"");
            sf.append(globalRefName + "." + cs[i].getCode() + "\"/>  \n");
          }
        }
      }
      else {
        Choice[] cs = field.getValue().getChoice();
        if ("select".equals(widget)) {
          sf.append("<html:select property=\"" + field.getName() + "\">\n");
          for (int i = 0; i < cs.length; i++) {
            sf.append("<html:option value=\"" + cs[i].getCode() + "\">");
            sf.append("<bean:message key=\"" + beanName + ".");
            sf.append(field.getName() + "." + cs[i].getCode() + "\"/>" +
                      "</html:option>\n");
          }
          sf.append("</html:select>");
        }
        else {
          for (int i = 0; i < cs.length; i++) {
            sf.append("<html:radio property=\"" + field.getName());
            sf.append("\" value=\"" + cs[i].getCode() + "\"/>" +
                      "<bean:message key=\"");
            sf.append(beanName + "." + field.getName() + "." + cs[i].getCode() +
                      "\"/>  \n");
          }
        }
      }
    }
    else if ("boolean".equals(type)) {
      sf.append("<html:checkbox property=\"" + field.getName() + "\"/>");
    }
    else if ("string".equals(type) || "email".equals(type) ||
             "creditcard".equals(type)) {
      sf.append("<html:text property=\"" + field.getName() + "\" size=\"" + len +
                "\"/>");
    }
    else if ("memo".equals(type)) {
      sf.append("<html:textarea property=\"" + field.getName() +
                "\"cols=\"60\" rows=\"" + 10 + "\"/>");
    }
    else if ("password".equals(type)) {
      sf.append("<html:password property=\"" + field.getName() + "\" size=\"" +
                len + "\"/>");
      sf.append("<br><html:password property=\"" + field.getName() +
                "2\" size=\"" + len + "\"/>");
    }
    else if ("int".equals(type)) {
      sf.append("<html:text property=\"" + field.getName() + "\" size=\"8\"/>");
    }
    else if ("long".equals(type) || "float".equals(type) ||
             "double".equals(type)) {
      sf.append("<html:text property=\"" + field.getName() + "\" size=\"16\"/>");
    }
    else if ("short".equals(type) || "byte".equals(type)) {
      sf.append("<html:text property=\"" + field.getName() + "\" size=\"4\"/>");
    }
    else if ("char".equals(type)) {
      sf.append("<html:text property=\"" + field.getName() + "\" size=\"1\"/>");
    }
    else if ("date".equals(type)) {
      sf.append("<html:text property=\"" + field.getName() + "\" size=\"");
      sf.append(dateFormat.length() + "\"/>(" + dateFormat + ")");
    }
    else if ("timestamp".equals(type)) {
      sf.append("<html:text property=\"" + field.getName() + "\" size=\"30\"/>");
      sf.append("(yyyy-mm-dd hh:mm:ss.fffffffff)");
    }
    return sf.toString();
  }

  /**
   *  SQL type mapping.
   *
   *@param  type
   *@param  nonNull
   *@param  length
   *@return
   */
  private String sqlType(String type, boolean nonNull, int length) {
    String sqlType;
    if (sqlTypeMap.containsKey(type)) {
      sqlType = (String) sqlTypeMap.get(type);
    }
    else if ("password".equalsIgnoreCase(type)) {
      sqlType = (String) sqlTypeMap.get("string");
    }
    else {
      sqlType = "UNKNOWN";
    }

    if ("string".equals(type) || "password".equals(type)) {
      sqlType += "(" + length + ")";
    }

    if (nonNull) {
      sqlType += " NOT NULL";
    }
    return sqlType;
  }

  private String requestParam(String name, String type) {
    type = javaType(type);
    String result;
    if ("String".equals(type)) {
      result = "request.getParameter(\"" + name + "\")";
    }
    else if ("Timestamp".equals(type)) {
      result = "java.sql.Timestamp.valueOf(request.getParameter(\"" + name +
          "\"))";
    }
    else if ("int".equals(type)) {
      result = "Integer.parseInt(request.getParameter(\"" + name + "\"))";
    }
    else {
      result = firstUpper(type) + ".parse" + firstUpper(type) +
          "(request.getParameter(\"" + name + "\"))";
    }
    return result;
  }

  /**
   * Escape xml string.
   * @param xml
   * @return
   */
  public String escapeXML(String xml) {
    String result = "";
    for (int i = 0; i < xml.length(); i++) {
      switch (xml.charAt(i)) {
        case '<':
          result += "&lt;";
          break;
        case '>':
          result += "&gt;";
          break;
        default:
          result += xml.charAt(i);
      }
    }
    return result;
  }
}

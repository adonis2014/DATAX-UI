package com.iharding.generator.test;

import junit.framework.TestCase;

import com.iharding.generator.strutsgen.*;
import com.iharding.generator.xml.*;

public class UtilTest extends TestCase {
  Util util = new Util();

  public UtilTest(String name) {
    super(name);
  }

  public static void main (String[] args) {
    junit.swingui.TestRunner.run(UtilTest.class);
  }

  public void testJava2sqlName() {
    assertEquals("first_name", util.java2sqlName("firstName"));
    assertEquals("name", util.java2sqlName("name"));
    assertEquals("name_dao", util.java2sqlName("nameDAO"));
    assertEquals("public123", util.java2sqlName("public123"));
  }

  public void testSql2javaName() {
    assertEquals("firstName", util.sql2javaName("first_name"));
    assertEquals("name", util.sql2javaName("name"));
    assertEquals("name", util.sql2javaName("name_"));
    assertEquals("nameDAO", util.sql2javaName("name_d_a_o"));
    assertEquals("public123", util.sql2javaName("public123"));
  }

  public void testGetValidationDependencies0() {
    assertEquals("", util.getValidationDependencies("string", null));
  }

  public void testGetValidationDependencies1() {
    Validation val = new Validation();
    val.setRequired(false);
    val.setMaxLength(20);
    assertEquals("maxLength", util.getValidationDependencies("string", val));
  }

  public void testGetValidationDependencies2() {
    Validation val = new Validation();
    val.setRequired(true);
    val.setMaxLength(30);
    assertEquals("required,maxLength", util.getValidationDependencies("string", val));
  }

}

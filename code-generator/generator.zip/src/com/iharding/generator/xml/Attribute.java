

package com.iharding.generator.xml;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.io.Reader;
import java.io.Serializable;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Enumeration;
import org.exolab.castor.xml.*;
import org.exolab.castor.xml.MarshalException;
import org.exolab.castor.xml.ValidationException;
import org.xml.sax.DocumentHandler;

/**
 *
 * @version $Revision$ $Date$
**/
public class Attribute implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    private java.util.ArrayList _columnList;


      //----------------/
     //- Constructors -/
    //----------------/

    public Attribute() {
        super();
        _columnList = new ArrayList();
    } //-- com.javanovic.karapansapi.xml.Attribute()


      //-----------/
     //- Methods -/
    //-----------/

    /**
     *
     * @param vColumn
    **/
    public void addColumn(Column vColumn)
        throws java.lang.IndexOutOfBoundsException
    {
        _columnList.add(vColumn);
    } //-- void addColumn(Column)

    /**
    **/
    public void clearColumn()
    {
        _columnList.clear();
    } //-- void clearColumn()

    /**
    **/
    public java.util.Enumeration enumerateColumn()
    {
        return new org.exolab.castor.util.IteratorEnumeration(_columnList.iterator());
    } //-- java.util.Enumeration enumerateColumn()

    /**
     *
     * @param index
    **/
    public Column getColumn(int index)
        throws java.lang.IndexOutOfBoundsException
    {
        //-- check bounds for index
        if ((index < 0) || (index > _columnList.size())) {
            throw new IndexOutOfBoundsException();
        }

        return (Column) _columnList.get(index);
    } //-- Column getColumn(int)

    /**
    **/
    public Column[] getColumn()
    {
        int size = _columnList.size();
        Column[] mArray = new Column[size];
        for (int index = 0; index < size; index++) {
            mArray[index] = (Column) _columnList.get(index);
        }
        return mArray;
    } //-- Column[] getColumn()

    /**
    **/
    public int getColumnCount()
    {
        return _columnList.size();
    } //-- int getColumnCount()

    /**
    **/
    public boolean isValid()
    {
        try {
            validate();
        }
        catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    } //-- boolean isValid()

    /**
     *
     * @param out
    **/
    public void marshal(java.io.Writer out)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {

        Marshaller.marshal(this, out);
    } //-- void marshal(java.io.Writer)

    /**
     *
     * @param handler
    **/
    public void marshal(org.xml.sax.DocumentHandler handler)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {

        Marshaller.marshal(this, handler);
    } //-- void marshal(org.xml.sax.DocumentHandler)

    /**
     *
     * @param vColumn
    **/
    public boolean removeColumn(Column vColumn)
    {
        boolean removed = _columnList.remove(vColumn);
        return removed;
    } //-- boolean removeColumn(Column)

    /**
     *
     * @param index
     * @param vColumn
    **/
    public void setColumn(int index, Column vColumn)
        throws java.lang.IndexOutOfBoundsException
    {
        //-- check bounds for index
        if ((index < 0) || (index > _columnList.size())) {
            throw new IndexOutOfBoundsException();
        }
        _columnList.set(index, vColumn);
    } //-- void setColumn(int, Column)

    /**
     *
     * @param columnArray
    **/
    public void setColumn(Column[] columnArray)
    {
        //-- copy array
        _columnList.clear();
        for (int i = 0; i < columnArray.length; i++) {
            _columnList.add(columnArray[i]);
        }
    } //-- void setColumn(Column)

    /**
     *
     * @param reader
    **/
    public static com.iharding.generator.xml.Attribute unmarshal(java.io.Reader reader)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        return (com.iharding.generator.xml.Attribute) Unmarshaller.unmarshal(com.iharding.generator.xml.Attribute.class, reader);
    } //-- com.javanovic.karapansapi.xml.Attribute unmarshal(java.io.Reader)

    /**
    **/
    public void validate()
        throws org.exolab.castor.xml.ValidationException
    {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    } //-- void validate()

}

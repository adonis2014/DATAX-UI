

package com.iharding.generator.xml;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.io.Reader;
import java.io.Serializable;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Enumeration;
import org.exolab.castor.xml.*;
import org.exolab.castor.xml.MarshalException;
import org.exolab.castor.xml.ValidationException;
import org.xml.sax.DocumentHandler;

/**
 *
 * @version $Revision$ $Date$
**/
public class Bean implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    private java.lang.String _name;

    private java.lang.String _sqlName;

    private java.lang.String _title;
    
    private java.lang.String _moduleName;
    /**
     * Cache object's minute to live
    **/
    private int _cacheMtl;

    /**
     * keeps track of state for field: _cacheMtl
    **/
    private boolean _has_cacheMtl;

    private boolean _generateDao;

    /**
     * keeps track of state for field: _generateDao
    **/
    private boolean _has_generateDao;

    private boolean _generateProcess;

    /**
     * keeps track of state for field: _generateProcess
    **/
    private boolean _has_generateProcess;

    private int _pageLength;

    /**
     * keeps track of state for field: _pageLength
    **/
    private boolean _has_pageLength;

    private boolean _javascriptValidation;

    /**
     * keeps track of state for field: _javascriptValidation
    **/
    private boolean _has_javascriptValidation;

    private PrimaryKey _primaryKey;

    private Attribute _attribute;

    private java.util.ArrayList _queryList;

    private java.util.ArrayList _processList;


      //----------------/
     //- Constructors -/
    //----------------/

    public Bean() {
        super();
        _queryList = new ArrayList();
        _processList = new ArrayList();
    } //-- com.javanovic.karapansapi.xml.Bean()


      //-----------/
     //- Methods -/
    //-----------/

    /**
     *
     * @param vProcess
    **/
    public void addProcess(Process vProcess)
        throws java.lang.IndexOutOfBoundsException
    {
        _processList.add(vProcess);
    } //-- void addProcess(Process)

    /**
     *
     * @param vQuery
    **/
    public void addQuery(Query vQuery)
        throws java.lang.IndexOutOfBoundsException
    {
        _queryList.add(vQuery);
    } //-- void addQuery(Query)

    /**
    **/
    public void clearProcess()
    {
        _processList.clear();
    } //-- void clearProcess()

    /**
    **/
    public void clearQuery()
    {
        _queryList.clear();
    } //-- void clearQuery()

    /**
    **/
    public void deleteCacheMtl()
    {
        this._has_cacheMtl= false;
    } //-- void deleteCacheMtl()

    /**
    **/
    public void deleteJavascriptValidation()
    {
        this._has_javascriptValidation= false;
    } //-- void deleteJavascriptValidation()

    /**
    **/
    public void deletePageLength()
    {
        this._has_pageLength= false;
    } //-- void deletePageLength()

    /**
    **/
    public java.util.Enumeration enumerateProcess()
    {
        return new org.exolab.castor.util.IteratorEnumeration(_processList.iterator());
    } //-- java.util.Enumeration enumerateProcess()

    /**
    **/
    public java.util.Enumeration enumerateQuery()
    {
        return new org.exolab.castor.util.IteratorEnumeration(_queryList.iterator());
    } //-- java.util.Enumeration enumerateQuery()

    /**
    **/
    public Attribute getAttribute()
    {
        return this._attribute;
    } //-- Attribute getAttribute()

    /**
    **/
    public int getCacheMtl()
    {
        return this._cacheMtl;
    } //-- int getCacheMtl()

    /**
    **/
    public boolean getGenerateDao()
    {
        return this._generateDao;
    } //-- boolean getGenerateDao()

    /**
    **/
    public boolean getGenerateProcess()
    {
        return this._generateProcess;
    } //-- boolean getGenerateProcess()

    /**
    **/
    public boolean getJavascriptValidation()
    {
        return this._javascriptValidation;
    } //-- boolean getJavascriptValidation()

    /**
    **/
    public java.lang.String getName()
    {
        return this._name;
    } //-- java.lang.String getName()

    /**
    **/
    public int getPageLength()
    {
        return this._pageLength;
    } //-- int getPageLength()

    /**
    **/
    public PrimaryKey getPrimaryKey()
    {
        return this._primaryKey;
    } //-- PrimaryKey getPrimaryKey()

    /**
     *
     * @param index
    **/
    public Process getProcess(int index)
        throws java.lang.IndexOutOfBoundsException
    {
        //-- check bounds for index
        if ((index < 0) || (index > _processList.size())) {
            throw new IndexOutOfBoundsException();
        }

        return (Process) _processList.get(index);
    } //-- Process getProcess(int)

    /**
    **/
    public Process[] getProcess()
    {
        int size = _processList.size();
        Process[] mArray = new Process[size];
        for (int index = 0; index < size; index++) {
            mArray[index] = (Process) _processList.get(index);
        }
        return mArray;
    } //-- Process[] getProcess()

    /**
    **/
    public int getProcessCount()
    {
        return _processList.size();
    } //-- int getProcessCount()

    /**
     *
     * @param index
    **/
    public Query getQuery(int index)
        throws java.lang.IndexOutOfBoundsException
    {
        //-- check bounds for index
        if ((index < 0) || (index > _queryList.size())) {
            throw new IndexOutOfBoundsException();
        }

        return (Query) _queryList.get(index);
    } //-- Query getQuery(int)

    /**
    **/
    public Query[] getQuery()
    {
        int size = _queryList.size();
        Query[] mArray = new Query[size];
        for (int index = 0; index < size; index++) {
            mArray[index] = (Query) _queryList.get(index);
        }
        return mArray;
    } //-- Query[] getQuery()

    /**
    **/
    public int getQueryCount()
    {
        return _queryList.size();
    } //-- int getQueryCount()

    /**
    **/
    public java.lang.String getSqlName()
    {
        return this._sqlName;
    } //-- java.lang.String getSqlName()

    /**
    **/
    public boolean hasCacheMtl()
    {
        return this._has_cacheMtl;
    } //-- boolean hasCacheMtl()

    /**
    **/
    public boolean hasGenerateDao()
    {
        return this._has_generateDao;
    } //-- boolean hasGenerateDao()

    /**
    **/
    public boolean hasGenerateProcess()
    {
        return this._has_generateProcess;
    } //-- boolean hasGenerateProcess()

    /**
    **/
    public boolean hasJavascriptValidation()
    {
        return this._has_javascriptValidation;
    } //-- boolean hasJavascriptValidation()

    /**
    **/
    public boolean hasPageLength()
    {
        return this._has_pageLength;
    } //-- boolean hasPageLength()

    /**
    **/
    public boolean isValid()
    {
        try {
            validate();
        }
        catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    } //-- boolean isValid()

    /**
     *
     * @param out
    **/
    public void marshal(java.io.Writer out)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {

        Marshaller.marshal(this, out);
    } //-- void marshal(java.io.Writer)

    /**
     *
     * @param handler
    **/
    public void marshal(org.xml.sax.DocumentHandler handler)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {

        Marshaller.marshal(this, handler);
    } //-- void marshal(org.xml.sax.DocumentHandler)

    /**
     *
     * @param vProcess
    **/
    public boolean removeProcess(Process vProcess)
    {
        boolean removed = _processList.remove(vProcess);
        return removed;
    } //-- boolean removeProcess(Process)

    /**
     *
     * @param vQuery
    **/
    public boolean removeQuery(Query vQuery)
    {
        boolean removed = _queryList.remove(vQuery);
        return removed;
    } //-- boolean removeQuery(Query)

    /**
     *
     * @param attribute
    **/
    public void setAttribute(Attribute attribute)
    {
        this._attribute = attribute;
    } //-- void setAttribute(Attribute)

    /**
     *
     * @param cacheMtl
    **/
    public void setCacheMtl(int cacheMtl)
    {
        this._cacheMtl = cacheMtl;
        this._has_cacheMtl = true;
    } //-- void setCacheMtl(int)

    /**
     *
     * @param generateDao
    **/
    public void setGenerateDao(boolean generateDao)
    {
        this._generateDao = generateDao;
        this._has_generateDao = true;
    } //-- void setGenerateDao(boolean)

    /**
     *
     * @param generateProcess
    **/
    public void setGenerateProcess(boolean generateProcess)
    {
        this._generateProcess = generateProcess;
        this._has_generateProcess = true;
    } //-- void setGenerateProcess(boolean)

    /**
     *
     * @param javascriptValidation
    **/
    public void setJavascriptValidation(boolean javascriptValidation)
    {
        this._javascriptValidation = javascriptValidation;
        this._has_javascriptValidation = true;
    } //-- void setJavascriptValidation(boolean)

    /**
     *
     * @param name
    **/
    public void setName(java.lang.String name)
    {
        this._name = name;
    } //-- void setName(java.lang.String)

    /**
     *
     * @param pageLength
    **/
    public void setPageLength(int pageLength)
    {
        this._pageLength = pageLength;
        this._has_pageLength = true;
    } //-- void setPageLength(int)

    /**
     *
     * @param primaryKey
    **/
    public void setPrimaryKey(PrimaryKey primaryKey)
    {
        this._primaryKey = primaryKey;
    } //-- void setPrimaryKey(PrimaryKey)

    /**
     *
     * @param index
     * @param vProcess
    **/
    public void setProcess(int index, Process vProcess)
        throws java.lang.IndexOutOfBoundsException
    {
        //-- check bounds for index
        if ((index < 0) || (index > _processList.size())) {
            throw new IndexOutOfBoundsException();
        }
        _processList.set(index, vProcess);
    } //-- void setProcess(int, Process)

    /**
     *
     * @param processArray
    **/
    public void setProcess(Process[] processArray)
    {
        //-- copy array
        _processList.clear();
        for (int i = 0; i < processArray.length; i++) {
            _processList.add(processArray[i]);
        }
    } //-- void setProcess(Process)

    /**
     *
     * @param index
     * @param vQuery
    **/
    public void setQuery(int index, Query vQuery)
        throws java.lang.IndexOutOfBoundsException
    {
        //-- check bounds for index
        if ((index < 0) || (index > _queryList.size())) {
            throw new IndexOutOfBoundsException();
        }
        _queryList.set(index, vQuery);
    } //-- void setQuery(int, Query)

    /**
     *
     * @param queryArray
    **/
    public void setQuery(Query[] queryArray)
    {
        //-- copy array
        _queryList.clear();
        for (int i = 0; i < queryArray.length; i++) {
            _queryList.add(queryArray[i]);
        }
    } //-- void setQuery(Query)

    /**
     *
     * @param sqlName
    **/
    public void setSqlName(java.lang.String sqlName)
    {
        this._sqlName = sqlName;
    } //-- void setSqlName(java.lang.String)

    /**
     *
     * @param reader
    **/
    public static com.iharding.generator.xml.Bean unmarshal(java.io.Reader reader)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        return (com.iharding.generator.xml.Bean) Unmarshaller.unmarshal(com.iharding.generator.xml.Bean.class, reader);
    } //-- com.javanovic.karapansapi.xml.Bean unmarshal(java.io.Reader)

    /**
    **/
    public void validate()
        throws org.exolab.castor.xml.ValidationException
    {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    } //-- void validate()


	public java.lang.String getTitle() {
		return _title;
	}


	public void setTitle(java.lang.String _title) {
		this._title = _title;
	}


	public java.lang.String getModuleName() {
		return _moduleName;
	}

	public void setModuleName(java.lang.String _moduleName) {
		this._moduleName = _moduleName;
	}

}

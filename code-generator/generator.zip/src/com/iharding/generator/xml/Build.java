

package com.iharding.generator.xml;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.io.Reader;
import java.io.Serializable;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Enumeration;
import org.exolab.castor.xml.*;
import org.exolab.castor.xml.MarshalException;
import org.exolab.castor.xml.ValidationException;
import org.xml.sax.DocumentHandler;

/**
 * Information about project build property
 * @version $Revision$ $Date$
**/
public class Build implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    private java.lang.String _directory;

    private java.lang.String _package;
    private java.lang.String _moduleName;
    
    private java.lang.String _warFileName;

    private java.lang.String _compiler;

    private java.util.ArrayList _libraryPathList;

    private java.lang.String _servletContainerName;

    private java.lang.String _servletContainerDir;

    private java.lang.String _dateFormat;

    private java.lang.String _urlPattern;


      //----------------/
     //- Constructors -/
    //----------------/

    public Build() {
        super();
        _libraryPathList = new ArrayList();
    } //-- com.javanovic.karapansapi.xml.Build()


      //-----------/
     //- Methods -/
    //-----------/

    /**
     *
     * @param vLibraryPath
    **/
    public void addLibraryPath(java.lang.String vLibraryPath)
        throws java.lang.IndexOutOfBoundsException
    {
        _libraryPathList.add(vLibraryPath);
    } //-- void addLibraryPath(java.lang.String)

    /**
    **/
    public void clearLibraryPath()
    {
        _libraryPathList.clear();
    } //-- void clearLibraryPath()

    /**
    **/
    public java.util.Enumeration enumerateLibraryPath()
    {
        return new org.exolab.castor.util.IteratorEnumeration(_libraryPathList.iterator());
    } //-- java.util.Enumeration enumerateLibraryPath()

    /**
    **/
    public java.lang.String getCompiler()
    {
        return this._compiler;
    } //-- java.lang.String getCompiler()

    /**
    **/
    public java.lang.String getDateFormat()
    {
        return this._dateFormat;
    } //-- java.lang.String getDateFormat()

    /**
    **/
    public java.lang.String getDirectory()
    {
        return this._directory;
    } //-- java.lang.String getDirectory()

    /**
     *
     * @param index
    **/
    public java.lang.String getLibraryPath(int index)
        throws java.lang.IndexOutOfBoundsException
    {
        //-- check bounds for index
        if ((index < 0) || (index > _libraryPathList.size())) {
            throw new IndexOutOfBoundsException();
        }

        return (String)_libraryPathList.get(index);
    } //-- java.lang.String getLibraryPath(int)

    /**
    **/
    public java.lang.String[] getLibraryPath()
    {
        int size = _libraryPathList.size();
        java.lang.String[] mArray = new String[size];
        for (int index = 0; index < size; index++) {
            mArray[index] = (String)_libraryPathList.get(index);
        }
        return mArray;
    } //-- java.lang.String[] getLibraryPath()

    /**
    **/
    public int getLibraryPathCount()
    {
        return _libraryPathList.size();
    } //-- int getLibraryPathCount()

    /**
    **/
    public java.lang.String getPackage()
    {
        return this._package;
    } //-- java.lang.String getPackage()

    /**
    **/
    public java.lang.String getServletContainerDir()
    {
        return this._servletContainerDir;
    } //-- java.lang.String getServletContainerDir()

    /**
    **/
    public java.lang.String getServletContainerName()
    {
        return this._servletContainerName;
    } //-- java.lang.String getServletContainerName()

    /**
    **/
    public java.lang.String getUrlPattern()
    {
        return this._urlPattern;
    } //-- java.lang.String getUrlPattern()

    /**
    **/
    public java.lang.String getWarFileName()
    {
        return this._warFileName;
    } //-- java.lang.String getWarFileName()

    /**
    **/
    public boolean isValid()
    {
        try {
            validate();
        }
        catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    } //-- boolean isValid()

    /**
     *
     * @param out
    **/
    public void marshal(java.io.Writer out)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {

        Marshaller.marshal(this, out);
    } //-- void marshal(java.io.Writer)

    /**
     *
     * @param handler
    **/
    public void marshal(org.xml.sax.DocumentHandler handler)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {

        Marshaller.marshal(this, handler);
    } //-- void marshal(org.xml.sax.DocumentHandler)

    /**
     *
     * @param vLibraryPath
    **/
    public boolean removeLibraryPath(java.lang.String vLibraryPath)
    {
        boolean removed = _libraryPathList.remove(vLibraryPath);
        return removed;
    } //-- boolean removeLibraryPath(java.lang.String)

    /**
     *
     * @param compiler
    **/
    public void setCompiler(java.lang.String compiler)
    {
        this._compiler = compiler;
    } //-- void setCompiler(java.lang.String)

    /**
     *
     * @param dateFormat
    **/
    public void setDateFormat(java.lang.String dateFormat)
    {
        this._dateFormat = dateFormat;
    } //-- void setDateFormat(java.lang.String)

    /**
     *
     * @param directory
    **/
    public void setDirectory(java.lang.String directory)
    {
        this._directory = directory;
    } //-- void setDirectory(java.lang.String)

    /**
     *
     * @param index
     * @param vLibraryPath
    **/
    public void setLibraryPath(int index, java.lang.String vLibraryPath)
        throws java.lang.IndexOutOfBoundsException
    {
        //-- check bounds for index
        if ((index < 0) || (index > _libraryPathList.size())) {
            throw new IndexOutOfBoundsException();
        }
        _libraryPathList.set(index, vLibraryPath);
    } //-- void setLibraryPath(int, java.lang.String)

    /**
     *
     * @param libraryPathArray
    **/
    public void setLibraryPath(java.lang.String[] libraryPathArray)
    {
        //-- copy array
        _libraryPathList.clear();
        for (int i = 0; i < libraryPathArray.length; i++) {
            _libraryPathList.add(libraryPathArray[i]);
        }
    } //-- void setLibraryPath(java.lang.String)

    /**
     *
     * @param _package
    **/
    public void setPackage(java.lang.String _package)
    {
        this._package = _package;
    } //-- void setPackage(java.lang.String)

    /**
     *
     * @param servletContainerDir
    **/
    public void setServletContainerDir(java.lang.String servletContainerDir)
    {
        this._servletContainerDir = servletContainerDir;
    } //-- void setServletContainerDir(java.lang.String)

    /**
     *
     * @param servletContainerName
    **/
    public void setServletContainerName(java.lang.String servletContainerName)
    {
        this._servletContainerName = servletContainerName;
    } //-- void setServletContainerName(java.lang.String)

    /**
     *
     * @param urlPattern
    **/
    public void setUrlPattern(java.lang.String urlPattern)
    {
        this._urlPattern = urlPattern;
    } //-- void setUrlPattern(java.lang.String)

    /**
     *
     * @param warFileName
    **/
    public void setWarFileName(java.lang.String warFileName)
    {
        this._warFileName = warFileName;
    } //-- void setWarFileName(java.lang.String)

    /**
     *
     * @param reader
    **/
    public static com.iharding.generator.xml.Build unmarshal(java.io.Reader reader)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        return (com.iharding.generator.xml.Build) Unmarshaller.unmarshal(com.iharding.generator.xml.Build.class, reader);
    } //-- com.javanovic.karapansapi.xml.Build unmarshal(java.io.Reader)

    /**
    **/
    public void validate()
        throws org.exolab.castor.xml.ValidationException
    {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    } //-- void validate()


	public java.lang.String getModuleName() {
		return _moduleName;
	}


	public void setModuleName(java.lang.String _moduleName) {
		this._moduleName = _moduleName;
	}

}

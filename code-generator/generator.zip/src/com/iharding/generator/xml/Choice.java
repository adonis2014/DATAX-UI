

package com.iharding.generator.xml;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.io.Reader;
import java.io.Serializable;
import java.io.Writer;
import org.exolab.castor.xml.*;
import org.exolab.castor.xml.MarshalException;
import org.exolab.castor.xml.ValidationException;
import org.xml.sax.DocumentHandler;

/**
 *
 * @version $Revision$ $Date$
**/
public class Choice implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    private java.lang.String _code;

    private java.lang.String _display;


      //----------------/
     //- Constructors -/
    //----------------/

    public Choice() {
        super();
    } //-- com.javanovic.karapansapi.xml.Choice()


      //-----------/
     //- Methods -/
    //-----------/

    /**
    **/
    public java.lang.String getCode()
    {
        return this._code;
    } //-- java.lang.String getCode()

    /**
    **/
    public java.lang.String getDisplay()
    {
        return this._display;
    } //-- java.lang.String getDisplay()

    /**
    **/
    public boolean isValid()
    {
        try {
            validate();
        }
        catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    } //-- boolean isValid()

    /**
     *
     * @param out
    **/
    public void marshal(java.io.Writer out)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {

        Marshaller.marshal(this, out);
    } //-- void marshal(java.io.Writer)

    /**
     *
     * @param handler
    **/
    public void marshal(org.xml.sax.DocumentHandler handler)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {

        Marshaller.marshal(this, handler);
    } //-- void marshal(org.xml.sax.DocumentHandler)

    /**
     *
     * @param code
    **/
    public void setCode(java.lang.String code)
    {
        this._code = code;
    } //-- void setCode(java.lang.String)

    /**
     *
     * @param display
    **/
    public void setDisplay(java.lang.String display)
    {
        this._display = display;
    } //-- void setDisplay(java.lang.String)

    /**
     *
     * @param reader
    **/
    public static com.iharding.generator.xml.Choice unmarshal(java.io.Reader reader)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        return (com.iharding.generator.xml.Choice) Unmarshaller.unmarshal(com.iharding.generator.xml.Choice.class, reader);
    } //-- com.javanovic.karapansapi.xml.Choice unmarshal(java.io.Reader)

    /**
    **/
    public void validate()
        throws org.exolab.castor.xml.ValidationException
    {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    } //-- void validate()

}

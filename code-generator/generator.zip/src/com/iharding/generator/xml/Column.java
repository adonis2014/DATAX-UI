

package com.iharding.generator.xml;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.io.Reader;
import java.io.Serializable;
import java.io.Writer;
import org.exolab.castor.xml.*;
import org.exolab.castor.xml.MarshalException;
import org.exolab.castor.xml.ValidationException;
import org.xml.sax.DocumentHandler;

/**
 *
 * @version $Revision$ $Date$
**/
public class Column implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    private java.lang.String _name;

    private java.lang.String _sqlName;

    private java.lang.String _title;

    private java.lang.String _type;

    private Validation _validation;

    private java.lang.String _format;

    private Value _value;


      //----------------/
     //- Constructors -/
    //----------------/

    public Column() {
        super();
    } //-- com.javanovic.karapansapi.xml.Column()


      //-----------/
     //- Methods -/
    //-----------/

    /**
    **/
    public java.lang.String getFormat()
    {
        return this._format;
    } //-- java.lang.String getFormat()

    /**
    **/
    public java.lang.String getName()
    {
        return this._name;
    } //-- java.lang.String getName()

    /**
    **/
    public java.lang.String getSqlName()
    {
        return this._sqlName;
    } //-- java.lang.String getSqlName()

    /**
    **/
    public java.lang.String getTitle()
    {
        return this._title;
    } //-- java.lang.String getTitle()

    /**
    **/
    public java.lang.String getType()
    {
        return this._type;
    } //-- java.lang.String getType()

    /**
    **/
    public Validation getValidation()
    {
        return this._validation;
    } //-- Validation getValidation()

    /**
    **/
    public Value getValue()
    {
        return this._value;
    } //-- Value getValue()

    /**
    **/
    public boolean isValid()
    {
        try {
            validate();
        }
        catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    } //-- boolean isValid()

    /**
     *
     * @param out
    **/
    public void marshal(java.io.Writer out)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {

        Marshaller.marshal(this, out);
    } //-- void marshal(java.io.Writer)

    /**
     *
     * @param handler
    **/
    public void marshal(org.xml.sax.DocumentHandler handler)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {

        Marshaller.marshal(this, handler);
    } //-- void marshal(org.xml.sax.DocumentHandler)

    /**
     *
     * @param format
    **/
    public void setFormat(java.lang.String format)
    {
        this._format = format;
    } //-- void setFormat(java.lang.String)

    /**
     *
     * @param name
    **/
    public void setName(java.lang.String name)
    {
        this._name = name;
    } //-- void setName(java.lang.String)

    /**
     *
     * @param sqlName
    **/
    public void setSqlName(java.lang.String sqlName)
    {
        this._sqlName = sqlName;
    } //-- void setSqlName(java.lang.String)

    /**
     *
     * @param title
    **/
    public void setTitle(java.lang.String title)
    {
        this._title = title;
    } //-- void setTitle(java.lang.String)

    /**
     *
     * @param type
    **/
    public void setType(java.lang.String type)
    {
        this._type = type;
    } //-- void setType(java.lang.String)

    /**
     *
     * @param validation
    **/
    public void setValidation(Validation validation)
    {
        this._validation = validation;
    } //-- void setValidation(Validation)

    /**
     *
     * @param value
    **/
    public void setValue(Value value)
    {
        this._value = value;
    } //-- void setValue(Value)

    /**
     *
     * @param reader
    **/
    public static com.iharding.generator.xml.Column unmarshal(java.io.Reader reader)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        return (com.iharding.generator.xml.Column) Unmarshaller.unmarshal(com.iharding.generator.xml.Column.class, reader);
    } //-- com.javanovic.karapansapi.xml.Column unmarshal(java.io.Reader)

    /**
    **/
    public void validate()
        throws org.exolab.castor.xml.ValidationException
    {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    } //-- void validate()

}

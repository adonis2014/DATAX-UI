

package com.iharding.generator.xml;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.io.Reader;
import java.io.Serializable;
import java.io.Writer;
import org.exolab.castor.xml.*;
import org.exolab.castor.xml.MarshalException;
import org.exolab.castor.xml.ValidationException;
import org.xml.sax.DocumentHandler;

/**
 *
 * @version $Revision$ $Date$
**/
public class Condition implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    private java.lang.String _fieldName;

    private java.lang.String _fieldCondition;


      //----------------/
     //- Constructors -/
    //----------------/

    public Condition() {
        super();
    } //-- com.javanovic.karapansapi.xml.Condition()


      //-----------/
     //- Methods -/
    //-----------/

    /**
    **/
    public java.lang.String getFieldCondition()
    {
        return this._fieldCondition;
    } //-- java.lang.String getFieldCondition()

    /**
    **/
    public java.lang.String getFieldName()
    {
        return this._fieldName;
    } //-- java.lang.String getFieldName()

    /**
    **/
    public boolean isValid()
    {
        try {
            validate();
        }
        catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    } //-- boolean isValid()

    /**
     *
     * @param out
    **/
    public void marshal(java.io.Writer out)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {

        Marshaller.marshal(this, out);
    } //-- void marshal(java.io.Writer)

    /**
     *
     * @param handler
    **/
    public void marshal(org.xml.sax.DocumentHandler handler)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {

        Marshaller.marshal(this, handler);
    } //-- void marshal(org.xml.sax.DocumentHandler)

    /**
     *
     * @param fieldCondition
    **/
    public void setFieldCondition(java.lang.String fieldCondition)
    {
        this._fieldCondition = fieldCondition;
    } //-- void setFieldCondition(java.lang.String)

    /**
     *
     * @param fieldName
    **/
    public void setFieldName(java.lang.String fieldName)
    {
        this._fieldName = fieldName;
    } //-- void setFieldName(java.lang.String)

    /**
     *
     * @param reader
    **/
    public static com.iharding.generator.xml.Condition unmarshal(java.io.Reader reader)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        return (com.iharding.generator.xml.Condition) Unmarshaller.unmarshal(com.iharding.generator.xml.Condition.class, reader);
    } //-- com.javanovic.karapansapi.xml.Condition unmarshal(java.io.Reader)

    /**
    **/
    public void validate()
        throws org.exolab.castor.xml.ValidationException
    {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    } //-- void validate()

}



package com.iharding.generator.xml;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.io.Reader;
import java.io.Serializable;
import java.io.Writer;
import org.exolab.castor.xml.*;
import org.exolab.castor.xml.MarshalException;
import org.exolab.castor.xml.ValidationException;
import org.xml.sax.DocumentHandler;

/**
 * Information about database
 * @version $Revision$ $Date$
**/
public class Database implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    private java.lang.String _dbms;

    private java.lang.String _driver;

    private java.lang.String _url;

    private java.lang.String _user;

    private java.lang.String _password;

    private java.lang.String _jndi;

    private int _minimumConnections;

    /**
     * keeps track of state for field: _minimumConnections
    **/
    private boolean _has_minimumConnections;

    private int _maximumConnections;

    /**
     * keeps track of state for field: _maximumConnections
    **/
    private boolean _has_maximumConnections;


      //----------------/
     //- Constructors -/
    //----------------/

    public Database() {
        super();
    } //-- com.javanovic.karapansapi.xml.Database()


      //-----------/
     //- Methods -/
    //-----------/

    /**
    **/
    public java.lang.String getDbms()
    {
        return this._dbms;
    } //-- java.lang.String getDbms()

    /**
    **/
    public java.lang.String getDriver()
    {
        return this._driver;
    } //-- java.lang.String getDriver()

    /**
    **/
    public java.lang.String getJndi()
    {
        return this._jndi;
    } //-- java.lang.String getJndi()

    /**
    **/
    public int getMaximumConnections()
    {
        return this._maximumConnections;
    } //-- int getMaximumConnections()

    /**
    **/
    public int getMinimumConnections()
    {
        return this._minimumConnections;
    } //-- int getMinimumConnections()

    /**
    **/
    public java.lang.String getPassword()
    {
        return this._password;
    } //-- java.lang.String getPassword()

    /**
    **/
    public java.lang.String getUrl()
    {
        return this._url;
    } //-- java.lang.String getUrl()

    /**
    **/
    public java.lang.String getUser()
    {
        return this._user;
    } //-- java.lang.String getUser()

    /**
    **/
    public boolean hasMaximumConnections()
    {
        return this._has_maximumConnections;
    } //-- boolean hasMaximumConnections()

    /**
    **/
    public boolean hasMinimumConnections()
    {
        return this._has_minimumConnections;
    } //-- boolean hasMinimumConnections()

    /**
    **/
    public boolean isValid()
    {
        try {
            validate();
        }
        catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    } //-- boolean isValid()

    /**
     *
     * @param out
    **/
    public void marshal(java.io.Writer out)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {

        Marshaller.marshal(this, out);
    } //-- void marshal(java.io.Writer)

    /**
     *
     * @param handler
    **/
    public void marshal(org.xml.sax.DocumentHandler handler)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {

        Marshaller.marshal(this, handler);
    } //-- void marshal(org.xml.sax.DocumentHandler)

    /**
     *
     * @param dbms
    **/
    public void setDbms(java.lang.String dbms)
    {
        this._dbms = dbms;
    } //-- void setDbms(java.lang.String)

    /**
     *
     * @param driver
    **/
    public void setDriver(java.lang.String driver)
    {
        this._driver = driver;
    } //-- void setDriver(java.lang.String)

    /**
     *
     * @param jndi
    **/
    public void setJndi(java.lang.String jndi)
    {
        this._jndi = jndi;
    } //-- void setJndi(java.lang.String)

    /**
     *
     * @param maximumConnections
    **/
    public void setMaximumConnections(int maximumConnections)
    {
        this._maximumConnections = maximumConnections;
        this._has_maximumConnections = true;
    } //-- void setMaximumConnections(int)

    /**
     *
     * @param minimumConnections
    **/
    public void setMinimumConnections(int minimumConnections)
    {
        this._minimumConnections = minimumConnections;
        this._has_minimumConnections = true;
    } //-- void setMinimumConnections(int)

    /**
     *
     * @param password
    **/
    public void setPassword(java.lang.String password)
    {
        this._password = password;
    } //-- void setPassword(java.lang.String)

    /**
     *
     * @param url
    **/
    public void setUrl(java.lang.String url)
    {
        this._url = url;
    } //-- void setUrl(java.lang.String)

    /**
     *
     * @param user
    **/
    public void setUser(java.lang.String user)
    {
        this._user = user;
    } //-- void setUser(java.lang.String)

    /**
     *
     * @param reader
    **/
    public static com.iharding.generator.xml.Database unmarshal(java.io.Reader reader)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        return (com.iharding.generator.xml.Database) Unmarshaller.unmarshal(com.iharding.generator.xml.Database.class, reader);
    } //-- com.javanovic.karapansapi.xml.Database unmarshal(java.io.Reader)

    /**
    **/
    public void validate()
        throws org.exolab.castor.xml.ValidationException
    {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    } //-- void validate()

}

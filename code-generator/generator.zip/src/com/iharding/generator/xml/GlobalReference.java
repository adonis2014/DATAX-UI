

package com.iharding.generator.xml;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.io.Reader;
import java.io.Serializable;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Enumeration;
import org.exolab.castor.xml.*;
import org.exolab.castor.xml.MarshalException;
import org.exolab.castor.xml.ValidationException;
import org.xml.sax.DocumentHandler;

/**
 * Reference that will be put in application or session scope
 * @version $Revision$ $Date$
**/
public class GlobalReference implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    private java.lang.String _name;

    private java.lang.String _beanName;

    private java.lang.String _queryName;

    private java.lang.String _scope;

    private java.util.ArrayList _paramList;


      //----------------/
     //- Constructors -/
    //----------------/

    public GlobalReference() {
        super();
        _paramList = new ArrayList();
    } //-- com.javanovic.karapansapi.xml.GlobalReference()


      //-----------/
     //- Methods -/
    //-----------/

    /**
     *
     * @param vParam
    **/
    public void addParam(java.lang.String vParam)
        throws java.lang.IndexOutOfBoundsException
    {
        _paramList.add(vParam);
    } //-- void addParam(java.lang.String)

    /**
    **/
    public void clearParam()
    {
        _paramList.clear();
    } //-- void clearParam()

    /**
    **/
    public java.util.Enumeration enumerateParam()
    {
        return new org.exolab.castor.util.IteratorEnumeration(_paramList.iterator());
    } //-- java.util.Enumeration enumerateParam()

    /**
    **/
    public java.lang.String getBeanName()
    {
        return this._beanName;
    } //-- java.lang.String getBeanName()

    /**
    **/
    public java.lang.String getName()
    {
        return this._name;
    } //-- java.lang.String getName()

    /**
     *
     * @param index
    **/
    public java.lang.String getParam(int index)
        throws java.lang.IndexOutOfBoundsException
    {
        //-- check bounds for index
        if ((index < 0) || (index > _paramList.size())) {
            throw new IndexOutOfBoundsException();
        }

        return (String)_paramList.get(index);
    } //-- java.lang.String getParam(int)

    /**
    **/
    public java.lang.String[] getParam()
    {
        int size = _paramList.size();
        java.lang.String[] mArray = new String[size];
        for (int index = 0; index < size; index++) {
            mArray[index] = (String)_paramList.get(index);
        }
        return mArray;
    } //-- java.lang.String[] getParam()

    /**
    **/
    public int getParamCount()
    {
        return _paramList.size();
    } //-- int getParamCount()

    /**
    **/
    public java.lang.String getQueryName()
    {
        return this._queryName;
    } //-- java.lang.String getQueryName()

    /**
    **/
    public java.lang.String getScope()
    {
        return this._scope;
    } //-- java.lang.String getScope()

    /**
    **/
    public boolean isValid()
    {
        try {
            validate();
        }
        catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    } //-- boolean isValid()

    /**
     *
     * @param out
    **/
    public void marshal(java.io.Writer out)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {

        Marshaller.marshal(this, out);
    } //-- void marshal(java.io.Writer)

    /**
     *
     * @param handler
    **/
    public void marshal(org.xml.sax.DocumentHandler handler)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {

        Marshaller.marshal(this, handler);
    } //-- void marshal(org.xml.sax.DocumentHandler)

    /**
     *
     * @param vParam
    **/
    public boolean removeParam(java.lang.String vParam)
    {
        boolean removed = _paramList.remove(vParam);
        return removed;
    } //-- boolean removeParam(java.lang.String)

    /**
     *
     * @param beanName
    **/
    public void setBeanName(java.lang.String beanName)
    {
        this._beanName = beanName;
    } //-- void setBeanName(java.lang.String)

    /**
     *
     * @param name
    **/
    public void setName(java.lang.String name)
    {
        this._name = name;
    } //-- void setName(java.lang.String)

    /**
     *
     * @param index
     * @param vParam
    **/
    public void setParam(int index, java.lang.String vParam)
        throws java.lang.IndexOutOfBoundsException
    {
        //-- check bounds for index
        if ((index < 0) || (index > _paramList.size())) {
            throw new IndexOutOfBoundsException();
        }
        _paramList.set(index, vParam);
    } //-- void setParam(int, java.lang.String)

    /**
     *
     * @param paramArray
    **/
    public void setParam(java.lang.String[] paramArray)
    {
        //-- copy array
        _paramList.clear();
        for (int i = 0; i < paramArray.length; i++) {
            _paramList.add(paramArray[i]);
        }
    } //-- void setParam(java.lang.String)

    /**
     *
     * @param queryName
    **/
    public void setQueryName(java.lang.String queryName)
    {
        this._queryName = queryName;
    } //-- void setQueryName(java.lang.String)

    /**
     *
     * @param scope
    **/
    public void setScope(java.lang.String scope)
    {
        this._scope = scope;
    } //-- void setScope(java.lang.String)

    /**
     *
     * @param reader
    **/
    public static com.iharding.generator.xml.GlobalReference unmarshal(java.io.Reader reader)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        return (com.iharding.generator.xml.GlobalReference) Unmarshaller.unmarshal(com.iharding.generator.xml.GlobalReference.class, reader);
    } //-- com.javanovic.karapansapi.xml.GlobalReference unmarshal(java.io.Reader)

    /**
    **/
    public void validate()
        throws org.exolab.castor.xml.ValidationException
    {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    } //-- void validate()

}

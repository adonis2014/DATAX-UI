

package com.iharding.generator.xml;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.io.Reader;
import java.io.Serializable;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Enumeration;
import org.exolab.castor.xml.*;
import org.exolab.castor.xml.MarshalException;
import org.exolab.castor.xml.ValidationException;
import org.xml.sax.DocumentHandler;

/**
 *
 * @version $Revision$ $Date$
**/
public class Menu implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    private java.lang.String _title;

    private java.util.ArrayList _menuItemList;

    private java.util.ArrayList _roleList;


      //----------------/
     //- Constructors -/
    //----------------/

    public Menu() {
        super();
        _menuItemList = new ArrayList();
        _roleList = new ArrayList();
    } //-- com.javanovic.karapansapi.xml.Menu()


      //-----------/
     //- Methods -/
    //-----------/

    /**
     *
     * @param vMenuItem
    **/
    public void addMenuItem(MenuItem vMenuItem)
        throws java.lang.IndexOutOfBoundsException
    {
        _menuItemList.add(vMenuItem);
    } //-- void addMenuItem(MenuItem)

    /**
     *
     * @param vRole
    **/
    public void addRole(java.lang.String vRole)
        throws java.lang.IndexOutOfBoundsException
    {
        _roleList.add(vRole);
    } //-- void addRole(java.lang.String)

    /**
    **/
    public void clearMenuItem()
    {
        _menuItemList.clear();
    } //-- void clearMenuItem()

    /**
    **/
    public void clearRole()
    {
        _roleList.clear();
    } //-- void clearRole()

    /**
    **/
    public java.util.Enumeration enumerateMenuItem()
    {
        return new org.exolab.castor.util.IteratorEnumeration(_menuItemList.iterator());
    } //-- java.util.Enumeration enumerateMenuItem()

    /**
    **/
    public java.util.Enumeration enumerateRole()
    {
        return new org.exolab.castor.util.IteratorEnumeration(_roleList.iterator());
    } //-- java.util.Enumeration enumerateRole()

    /**
     *
     * @param index
    **/
    public MenuItem getMenuItem(int index)
        throws java.lang.IndexOutOfBoundsException
    {
        //-- check bounds for index
        if ((index < 0) || (index > _menuItemList.size())) {
            throw new IndexOutOfBoundsException();
        }

        return (MenuItem) _menuItemList.get(index);
    } //-- MenuItem getMenuItem(int)

    /**
    **/
    public MenuItem[] getMenuItem()
    {
        int size = _menuItemList.size();
        MenuItem[] mArray = new MenuItem[size];
        for (int index = 0; index < size; index++) {
            mArray[index] = (MenuItem) _menuItemList.get(index);
        }
        return mArray;
    } //-- MenuItem[] getMenuItem()

    /**
    **/
    public int getMenuItemCount()
    {
        return _menuItemList.size();
    } //-- int getMenuItemCount()

    /**
     *
     * @param index
    **/
    public java.lang.String getRole(int index)
        throws java.lang.IndexOutOfBoundsException
    {
        //-- check bounds for index
        if ((index < 0) || (index > _roleList.size())) {
            throw new IndexOutOfBoundsException();
        }

        return (String)_roleList.get(index);
    } //-- java.lang.String getRole(int)

    /**
    **/
    public java.lang.String[] getRole()
    {
        int size = _roleList.size();
        java.lang.String[] mArray = new String[size];
        for (int index = 0; index < size; index++) {
            mArray[index] = (String)_roleList.get(index);
        }
        return mArray;
    } //-- java.lang.String[] getRole()

    /**
    **/
    public int getRoleCount()
    {
        return _roleList.size();
    } //-- int getRoleCount()

    /**
    **/
    public java.lang.String getTitle()
    {
        return this._title;
    } //-- java.lang.String getTitle()

    /**
    **/
    public boolean isValid()
    {
        try {
            validate();
        }
        catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    } //-- boolean isValid()

    /**
     *
     * @param out
    **/
    public void marshal(java.io.Writer out)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {

        Marshaller.marshal(this, out);
    } //-- void marshal(java.io.Writer)

    /**
     *
     * @param handler
    **/
    public void marshal(org.xml.sax.DocumentHandler handler)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {

        Marshaller.marshal(this, handler);
    } //-- void marshal(org.xml.sax.DocumentHandler)

    /**
     *
     * @param vMenuItem
    **/
    public boolean removeMenuItem(MenuItem vMenuItem)
    {
        boolean removed = _menuItemList.remove(vMenuItem);
        return removed;
    } //-- boolean removeMenuItem(MenuItem)

    /**
     *
     * @param vRole
    **/
    public boolean removeRole(java.lang.String vRole)
    {
        boolean removed = _roleList.remove(vRole);
        return removed;
    } //-- boolean removeRole(java.lang.String)

    /**
     *
     * @param index
     * @param vMenuItem
    **/
    public void setMenuItem(int index, MenuItem vMenuItem)
        throws java.lang.IndexOutOfBoundsException
    {
        //-- check bounds for index
        if ((index < 0) || (index > _menuItemList.size())) {
            throw new IndexOutOfBoundsException();
        }
        _menuItemList.set(index, vMenuItem);
    } //-- void setMenuItem(int, MenuItem)

    /**
     *
     * @param menuItemArray
    **/
    public void setMenuItem(MenuItem[] menuItemArray)
    {
        //-- copy array
        _menuItemList.clear();
        for (int i = 0; i < menuItemArray.length; i++) {
            _menuItemList.add(menuItemArray[i]);
        }
    } //-- void setMenuItem(MenuItem)

    /**
     *
     * @param index
     * @param vRole
    **/
    public void setRole(int index, java.lang.String vRole)
        throws java.lang.IndexOutOfBoundsException
    {
        //-- check bounds for index
        if ((index < 0) || (index > _roleList.size())) {
            throw new IndexOutOfBoundsException();
        }
        _roleList.set(index, vRole);
    } //-- void setRole(int, java.lang.String)

    /**
     *
     * @param roleArray
    **/
    public void setRole(java.lang.String[] roleArray)
    {
        //-- copy array
        _roleList.clear();
        for (int i = 0; i < roleArray.length; i++) {
            _roleList.add(roleArray[i]);
        }
    } //-- void setRole(java.lang.String)

    /**
     *
     * @param title
    **/
    public void setTitle(java.lang.String title)
    {
        this._title = title;
    } //-- void setTitle(java.lang.String)

    /**
     *
     * @param reader
    **/
    public static com.iharding.generator.xml.Menu unmarshal(java.io.Reader reader)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        return (com.iharding.generator.xml.Menu) Unmarshaller.unmarshal(com.iharding.generator.xml.Menu.class, reader);
    } //-- com.javanovic.karapansapi.xml.Menu unmarshal(java.io.Reader)

    /**
    **/
    public void validate()
        throws org.exolab.castor.xml.ValidationException
    {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    } //-- void validate()

}

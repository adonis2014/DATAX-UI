

package com.iharding.generator.xml;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.io.Reader;
import java.io.Serializable;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Enumeration;
import org.exolab.castor.xml.*;
import org.exolab.castor.xml.MarshalException;
import org.exolab.castor.xml.ValidationException;
import org.xml.sax.DocumentHandler;

/**
 *
 * @version $Revision$ $Date$
**/
public class Page implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    private java.lang.String _title;

    private java.util.ArrayList _fieldNameList;

    private java.util.ArrayList _forwardList;


      //----------------/
     //- Constructors -/
    //----------------/

    public Page() {
        super();
        _fieldNameList = new ArrayList();
        _forwardList = new ArrayList();
    } //-- com.javanovic.karapansapi.xml.Page()


      //-----------/
     //- Methods -/
    //-----------/

    /**
     *
     * @param vFieldName
    **/
    public void addFieldName(java.lang.String vFieldName)
        throws java.lang.IndexOutOfBoundsException
    {
        _fieldNameList.add(vFieldName);
    } //-- void addFieldName(java.lang.String)

    /**
     *
     * @param vForward
    **/
    public void addForward(Forward vForward)
        throws java.lang.IndexOutOfBoundsException
    {
        _forwardList.add(vForward);
    } //-- void addForward(Forward)

    /**
    **/
    public void clearFieldName()
    {
        _fieldNameList.clear();
    } //-- void clearFieldName()

    /**
    **/
    public void clearForward()
    {
        _forwardList.clear();
    } //-- void clearForward()

    /**
    **/
    public java.util.Enumeration enumerateFieldName()
    {
        return new org.exolab.castor.util.IteratorEnumeration(_fieldNameList.iterator());
    } //-- java.util.Enumeration enumerateFieldName()

    /**
    **/
    public java.util.Enumeration enumerateForward()
    {
        return new org.exolab.castor.util.IteratorEnumeration(_forwardList.iterator());
    } //-- java.util.Enumeration enumerateForward()

    /**
     *
     * @param index
    **/
    public java.lang.String getFieldName(int index)
        throws java.lang.IndexOutOfBoundsException
    {
        //-- check bounds for index
        if ((index < 0) || (index > _fieldNameList.size())) {
            throw new IndexOutOfBoundsException();
        }

        return (String)_fieldNameList.get(index);
    } //-- java.lang.String getFieldName(int)

    /**
    **/
    public java.lang.String[] getFieldName()
    {
        int size = _fieldNameList.size();
        java.lang.String[] mArray = new String[size];
        for (int index = 0; index < size; index++) {
            mArray[index] = (String)_fieldNameList.get(index);
        }
        return mArray;
    } //-- java.lang.String[] getFieldName()

    /**
    **/
    public int getFieldNameCount()
    {
        return _fieldNameList.size();
    } //-- int getFieldNameCount()

    /**
     *
     * @param index
    **/
    public Forward getForward(int index)
        throws java.lang.IndexOutOfBoundsException
    {
        //-- check bounds for index
        if ((index < 0) || (index > _forwardList.size())) {
            throw new IndexOutOfBoundsException();
        }

        return (Forward) _forwardList.get(index);
    } //-- Forward getForward(int)

    /**
    **/
    public Forward[] getForward()
    {
        int size = _forwardList.size();
        Forward[] mArray = new Forward[size];
        for (int index = 0; index < size; index++) {
            mArray[index] = (Forward) _forwardList.get(index);
        }
        return mArray;
    } //-- Forward[] getForward()

    /**
    **/
    public int getForwardCount()
    {
        return _forwardList.size();
    } //-- int getForwardCount()

    /**
    **/
    public java.lang.String getTitle()
    {
        return this._title;
    } //-- java.lang.String getTitle()

    /**
    **/
    public boolean isValid()
    {
        try {
            validate();
        }
        catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    } //-- boolean isValid()

    /**
     *
     * @param out
    **/
    public void marshal(java.io.Writer out)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {

        Marshaller.marshal(this, out);
    } //-- void marshal(java.io.Writer)

    /**
     *
     * @param handler
    **/
    public void marshal(org.xml.sax.DocumentHandler handler)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {

        Marshaller.marshal(this, handler);
    } //-- void marshal(org.xml.sax.DocumentHandler)

    /**
     *
     * @param vFieldName
    **/
    public boolean removeFieldName(java.lang.String vFieldName)
    {
        boolean removed = _fieldNameList.remove(vFieldName);
        return removed;
    } //-- boolean removeFieldName(java.lang.String)

    /**
     *
     * @param vForward
    **/
    public boolean removeForward(Forward vForward)
    {
        boolean removed = _forwardList.remove(vForward);
        return removed;
    } //-- boolean removeForward(Forward)

    /**
     *
     * @param index
     * @param vFieldName
    **/
    public void setFieldName(int index, java.lang.String vFieldName)
        throws java.lang.IndexOutOfBoundsException
    {
        //-- check bounds for index
        if ((index < 0) || (index > _fieldNameList.size())) {
            throw new IndexOutOfBoundsException();
        }
        _fieldNameList.set(index, vFieldName);
    } //-- void setFieldName(int, java.lang.String)

    /**
     *
     * @param fieldNameArray
    **/
    public void setFieldName(java.lang.String[] fieldNameArray)
    {
        //-- copy array
        _fieldNameList.clear();
        for (int i = 0; i < fieldNameArray.length; i++) {
            _fieldNameList.add(fieldNameArray[i]);
        }
    } //-- void setFieldName(java.lang.String)

    /**
     *
     * @param index
     * @param vForward
    **/
    public void setForward(int index, Forward vForward)
        throws java.lang.IndexOutOfBoundsException
    {
        //-- check bounds for index
        if ((index < 0) || (index > _forwardList.size())) {
            throw new IndexOutOfBoundsException();
        }
        _forwardList.set(index, vForward);
    } //-- void setForward(int, Forward)

    /**
     *
     * @param forwardArray
    **/
    public void setForward(Forward[] forwardArray)
    {
        //-- copy array
        _forwardList.clear();
        for (int i = 0; i < forwardArray.length; i++) {
            _forwardList.add(forwardArray[i]);
        }
    } //-- void setForward(Forward)

    /**
     *
     * @param title
    **/
    public void setTitle(java.lang.String title)
    {
        this._title = title;
    } //-- void setTitle(java.lang.String)

    /**
     *
     * @param reader
    **/
    public static com.iharding.generator.xml.Page unmarshal(java.io.Reader reader)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        return (com.iharding.generator.xml.Page) Unmarshaller.unmarshal(com.iharding.generator.xml.Page.class, reader);
    } //-- com.javanovic.karapansapi.xml.Page unmarshal(java.io.Reader)

    /**
    **/
    public void validate()
        throws org.exolab.castor.xml.ValidationException
    {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    } //-- void validate()

}

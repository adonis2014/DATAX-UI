

package com.iharding.generator.xml;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.io.Reader;
import java.io.Serializable;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Enumeration;
import org.exolab.castor.xml.*;
import org.exolab.castor.xml.MarshalException;
import org.exolab.castor.xml.ValidationException;
import org.xml.sax.DocumentHandler;

/**
 *
 * @version $Revision$ $Date$
**/
public class Query implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    private java.lang.String _name;

    private java.util.ArrayList _conditionList;

    private java.lang.String _result;

    private java.util.ArrayList _aggregateConditionList;

    private java.util.ArrayList _sortingList;


      //----------------/
     //- Constructors -/
    //----------------/

    public Query() {
        super();
        _conditionList = new ArrayList();
        _aggregateConditionList = new ArrayList();
        _sortingList = new ArrayList();
    } //-- com.javanovic.karapansapi.xml.Query()


      //-----------/
     //- Methods -/
    //-----------/

    /**
     *
     * @param vAggregateCondition
    **/
    public void addAggregateCondition(java.lang.String vAggregateCondition)
        throws java.lang.IndexOutOfBoundsException
    {
        _aggregateConditionList.add(vAggregateCondition);
    } //-- void addAggregateCondition(java.lang.String)

    /**
     *
     * @param vCondition
    **/
    public void addCondition(Condition vCondition)
        throws java.lang.IndexOutOfBoundsException
    {
        _conditionList.add(vCondition);
    } //-- void addCondition(Condition)

    /**
     *
     * @param vSorting
    **/
    public void addSorting(Sorting vSorting)
        throws java.lang.IndexOutOfBoundsException
    {
        _sortingList.add(vSorting);
    } //-- void addSorting(Sorting)

    /**
    **/
    public void clearAggregateCondition()
    {
        _aggregateConditionList.clear();
    } //-- void clearAggregateCondition()

    /**
    **/
    public void clearCondition()
    {
        _conditionList.clear();
    } //-- void clearCondition()

    /**
    **/
    public void clearSorting()
    {
        _sortingList.clear();
    } //-- void clearSorting()

    /**
    **/
    public java.util.Enumeration enumerateAggregateCondition()
    {
        return new org.exolab.castor.util.IteratorEnumeration(_aggregateConditionList.iterator());
    } //-- java.util.Enumeration enumerateAggregateCondition()

    /**
    **/
    public java.util.Enumeration enumerateCondition()
    {
        return new org.exolab.castor.util.IteratorEnumeration(_conditionList.iterator());
    } //-- java.util.Enumeration enumerateCondition()

    /**
    **/
    public java.util.Enumeration enumerateSorting()
    {
        return new org.exolab.castor.util.IteratorEnumeration(_sortingList.iterator());
    } //-- java.util.Enumeration enumerateSorting()

    /**
     *
     * @param index
    **/
    public java.lang.String getAggregateCondition(int index)
        throws java.lang.IndexOutOfBoundsException
    {
        //-- check bounds for index
        if ((index < 0) || (index > _aggregateConditionList.size())) {
            throw new IndexOutOfBoundsException();
        }

        return (String)_aggregateConditionList.get(index);
    } //-- java.lang.String getAggregateCondition(int)

    /**
    **/
    public java.lang.String[] getAggregateCondition()
    {
        int size = _aggregateConditionList.size();
        java.lang.String[] mArray = new String[size];
        for (int index = 0; index < size; index++) {
            mArray[index] = (String)_aggregateConditionList.get(index);
        }
        return mArray;
    } //-- java.lang.String[] getAggregateCondition()

    /**
    **/
    public int getAggregateConditionCount()
    {
        return _aggregateConditionList.size();
    } //-- int getAggregateConditionCount()

    /**
     *
     * @param index
    **/
    public Condition getCondition(int index)
        throws java.lang.IndexOutOfBoundsException
    {
        //-- check bounds for index
        if ((index < 0) || (index > _conditionList.size())) {
            throw new IndexOutOfBoundsException();
        }

        return (Condition) _conditionList.get(index);
    } //-- Condition getCondition(int)

    /**
    **/
    public Condition[] getCondition()
    {
        int size = _conditionList.size();
        Condition[] mArray = new Condition[size];
        for (int index = 0; index < size; index++) {
            mArray[index] = (Condition) _conditionList.get(index);
        }
        return mArray;
    } //-- Condition[] getCondition()

    /**
    **/
    public int getConditionCount()
    {
        return _conditionList.size();
    } //-- int getConditionCount()

    /**
    **/
    public java.lang.String getName()
    {
        return this._name;
    } //-- java.lang.String getName()

    /**
    **/
    public java.lang.String getResult()
    {
        return this._result;
    } //-- java.lang.String getResult()

    /**
     *
     * @param index
    **/
    public Sorting getSorting(int index)
        throws java.lang.IndexOutOfBoundsException
    {
        //-- check bounds for index
        if ((index < 0) || (index > _sortingList.size())) {
            throw new IndexOutOfBoundsException();
        }

        return (Sorting) _sortingList.get(index);
    } //-- Sorting getSorting(int)

    /**
    **/
    public Sorting[] getSorting()
    {
        int size = _sortingList.size();
        Sorting[] mArray = new Sorting[size];
        for (int index = 0; index < size; index++) {
            mArray[index] = (Sorting) _sortingList.get(index);
        }
        return mArray;
    } //-- Sorting[] getSorting()

    /**
    **/
    public int getSortingCount()
    {
        return _sortingList.size();
    } //-- int getSortingCount()

    /**
    **/
    public boolean isValid()
    {
        try {
            validate();
        }
        catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    } //-- boolean isValid()

    /**
     *
     * @param out
    **/
    public void marshal(java.io.Writer out)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {

        Marshaller.marshal(this, out);
    } //-- void marshal(java.io.Writer)

    /**
     *
     * @param handler
    **/
    public void marshal(org.xml.sax.DocumentHandler handler)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {

        Marshaller.marshal(this, handler);
    } //-- void marshal(org.xml.sax.DocumentHandler)

    /**
     *
     * @param vAggregateCondition
    **/
    public boolean removeAggregateCondition(java.lang.String vAggregateCondition)
    {
        boolean removed = _aggregateConditionList.remove(vAggregateCondition);
        return removed;
    } //-- boolean removeAggregateCondition(java.lang.String)

    /**
     *
     * @param vCondition
    **/
    public boolean removeCondition(Condition vCondition)
    {
        boolean removed = _conditionList.remove(vCondition);
        return removed;
    } //-- boolean removeCondition(Condition)

    /**
     *
     * @param vSorting
    **/
    public boolean removeSorting(Sorting vSorting)
    {
        boolean removed = _sortingList.remove(vSorting);
        return removed;
    } //-- boolean removeSorting(Sorting)

    /**
     *
     * @param index
     * @param vAggregateCondition
    **/
    public void setAggregateCondition(int index, java.lang.String vAggregateCondition)
        throws java.lang.IndexOutOfBoundsException
    {
        //-- check bounds for index
        if ((index < 0) || (index > _aggregateConditionList.size())) {
            throw new IndexOutOfBoundsException();
        }
        _aggregateConditionList.set(index, vAggregateCondition);
    } //-- void setAggregateCondition(int, java.lang.String)

    /**
     *
     * @param aggregateConditionArray
    **/
    public void setAggregateCondition(java.lang.String[] aggregateConditionArray)
    {
        //-- copy array
        _aggregateConditionList.clear();
        for (int i = 0; i < aggregateConditionArray.length; i++) {
            _aggregateConditionList.add(aggregateConditionArray[i]);
        }
    } //-- void setAggregateCondition(java.lang.String)

    /**
     *
     * @param index
     * @param vCondition
    **/
    public void setCondition(int index, Condition vCondition)
        throws java.lang.IndexOutOfBoundsException
    {
        //-- check bounds for index
        if ((index < 0) || (index > _conditionList.size())) {
            throw new IndexOutOfBoundsException();
        }
        _conditionList.set(index, vCondition);
    } //-- void setCondition(int, Condition)

    /**
     *
     * @param conditionArray
    **/
    public void setCondition(Condition[] conditionArray)
    {
        //-- copy array
        _conditionList.clear();
        for (int i = 0; i < conditionArray.length; i++) {
            _conditionList.add(conditionArray[i]);
        }
    } //-- void setCondition(Condition)

    /**
     *
     * @param name
    **/
    public void setName(java.lang.String name)
    {
        this._name = name;
    } //-- void setName(java.lang.String)

    /**
     *
     * @param result
    **/
    public void setResult(java.lang.String result)
    {
        this._result = result;
    } //-- void setResult(java.lang.String)

    /**
     *
     * @param index
     * @param vSorting
    **/
    public void setSorting(int index, Sorting vSorting)
        throws java.lang.IndexOutOfBoundsException
    {
        //-- check bounds for index
        if ((index < 0) || (index > _sortingList.size())) {
            throw new IndexOutOfBoundsException();
        }
        _sortingList.set(index, vSorting);
    } //-- void setSorting(int, Sorting)

    /**
     *
     * @param sortingArray
    **/
    public void setSorting(Sorting[] sortingArray)
    {
        //-- copy array
        _sortingList.clear();
        for (int i = 0; i < sortingArray.length; i++) {
            _sortingList.add(sortingArray[i]);
        }
    } //-- void setSorting(Sorting)

    /**
     *
     * @param reader
    **/
    public static com.iharding.generator.xml.Query unmarshal(java.io.Reader reader)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        return (com.iharding.generator.xml.Query) Unmarshaller.unmarshal(com.iharding.generator.xml.Query.class, reader);
    } //-- com.javanovic.karapansapi.xml.Query unmarshal(java.io.Reader)

    /**
    **/
    public void validate()
        throws org.exolab.castor.xml.ValidationException
    {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    } //-- void validate()

}

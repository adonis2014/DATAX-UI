

package com.iharding.generator.xml;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.io.Reader;
import java.io.Serializable;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Enumeration;
import org.exolab.castor.xml.*;
import org.exolab.castor.xml.MarshalException;
import org.exolab.castor.xml.ValidationException;
import org.xml.sax.DocumentHandler;

/**
 * Information about security constraint
 * @version $Revision$ $Date$
**/
public class Security implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    private java.util.ArrayList _securityRoleList;

    /**
     * Web Resource definition in web.xml file.
    **/
    private java.util.ArrayList _securityConstraintList;


      //----------------/
     //- Constructors -/
    //----------------/

    public Security() {
        super();
        _securityRoleList = new ArrayList();
        _securityConstraintList = new ArrayList();
    } //-- com.javanovic.karapansapi.xml.Security()


      //-----------/
     //- Methods -/
    //-----------/

    /**
     *
     * @param vSecurityConstraint
    **/
    public void addSecurityConstraint(SecurityConstraint vSecurityConstraint)
        throws java.lang.IndexOutOfBoundsException
    {
        _securityConstraintList.add(vSecurityConstraint);
    } //-- void addSecurityConstraint(SecurityConstraint)

    /**
     *
     * @param vSecurityRole
    **/
    public void addSecurityRole(java.lang.String vSecurityRole)
        throws java.lang.IndexOutOfBoundsException
    {
        _securityRoleList.add(vSecurityRole);
    } //-- void addSecurityRole(java.lang.String)

    /**
    **/
    public void clearSecurityConstraint()
    {
        _securityConstraintList.clear();
    } //-- void clearSecurityConstraint()

    /**
    **/
    public void clearSecurityRole()
    {
        _securityRoleList.clear();
    } //-- void clearSecurityRole()

    /**
    **/
    public java.util.Enumeration enumerateSecurityConstraint()
    {
        return new org.exolab.castor.util.IteratorEnumeration(_securityConstraintList.iterator());
    } //-- java.util.Enumeration enumerateSecurityConstraint()

    /**
    **/
    public java.util.Enumeration enumerateSecurityRole()
    {
        return new org.exolab.castor.util.IteratorEnumeration(_securityRoleList.iterator());
    } //-- java.util.Enumeration enumerateSecurityRole()

    /**
     *
     * @param index
    **/
    public SecurityConstraint getSecurityConstraint(int index)
        throws java.lang.IndexOutOfBoundsException
    {
        //-- check bounds for index
        if ((index < 0) || (index > _securityConstraintList.size())) {
            throw new IndexOutOfBoundsException();
        }

        return (SecurityConstraint) _securityConstraintList.get(index);
    } //-- SecurityConstraint getSecurityConstraint(int)

    /**
    **/
    public SecurityConstraint[] getSecurityConstraint()
    {
        int size = _securityConstraintList.size();
        SecurityConstraint[] mArray = new SecurityConstraint[size];
        for (int index = 0; index < size; index++) {
            mArray[index] = (SecurityConstraint) _securityConstraintList.get(index);
        }
        return mArray;
    } //-- SecurityConstraint[] getSecurityConstraint()

    /**
    **/
    public int getSecurityConstraintCount()
    {
        return _securityConstraintList.size();
    } //-- int getSecurityConstraintCount()

    /**
     *
     * @param index
    **/
    public java.lang.String getSecurityRole(int index)
        throws java.lang.IndexOutOfBoundsException
    {
        //-- check bounds for index
        if ((index < 0) || (index > _securityRoleList.size())) {
            throw new IndexOutOfBoundsException();
        }

        return (String)_securityRoleList.get(index);
    } //-- java.lang.String getSecurityRole(int)

    /**
    **/
    public java.lang.String[] getSecurityRole()
    {
        int size = _securityRoleList.size();
        java.lang.String[] mArray = new String[size];
        for (int index = 0; index < size; index++) {
            mArray[index] = (String)_securityRoleList.get(index);
        }
        return mArray;
    } //-- java.lang.String[] getSecurityRole()

    /**
    **/
    public int getSecurityRoleCount()
    {
        return _securityRoleList.size();
    } //-- int getSecurityRoleCount()

    /**
    **/
    public boolean isValid()
    {
        try {
            validate();
        }
        catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    } //-- boolean isValid()

    /**
     *
     * @param out
    **/
    public void marshal(java.io.Writer out)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {

        Marshaller.marshal(this, out);
    } //-- void marshal(java.io.Writer)

    /**
     *
     * @param handler
    **/
    public void marshal(org.xml.sax.DocumentHandler handler)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {

        Marshaller.marshal(this, handler);
    } //-- void marshal(org.xml.sax.DocumentHandler)

    /**
     *
     * @param vSecurityConstraint
    **/
    public boolean removeSecurityConstraint(SecurityConstraint vSecurityConstraint)
    {
        boolean removed = _securityConstraintList.remove(vSecurityConstraint);
        return removed;
    } //-- boolean removeSecurityConstraint(SecurityConstraint)

    /**
     *
     * @param vSecurityRole
    **/
    public boolean removeSecurityRole(java.lang.String vSecurityRole)
    {
        boolean removed = _securityRoleList.remove(vSecurityRole);
        return removed;
    } //-- boolean removeSecurityRole(java.lang.String)

    /**
     *
     * @param index
     * @param vSecurityConstraint
    **/
    public void setSecurityConstraint(int index, SecurityConstraint vSecurityConstraint)
        throws java.lang.IndexOutOfBoundsException
    {
        //-- check bounds for index
        if ((index < 0) || (index > _securityConstraintList.size())) {
            throw new IndexOutOfBoundsException();
        }
        _securityConstraintList.set(index, vSecurityConstraint);
    } //-- void setSecurityConstraint(int, SecurityConstraint)

    /**
     *
     * @param securityConstraintArray
    **/
    public void setSecurityConstraint(SecurityConstraint[] securityConstraintArray)
    {
        //-- copy array
        _securityConstraintList.clear();
        for (int i = 0; i < securityConstraintArray.length; i++) {
            _securityConstraintList.add(securityConstraintArray[i]);
        }
    } //-- void setSecurityConstraint(SecurityConstraint)

    /**
     *
     * @param index
     * @param vSecurityRole
    **/
    public void setSecurityRole(int index, java.lang.String vSecurityRole)
        throws java.lang.IndexOutOfBoundsException
    {
        //-- check bounds for index
        if ((index < 0) || (index > _securityRoleList.size())) {
            throw new IndexOutOfBoundsException();
        }
        _securityRoleList.set(index, vSecurityRole);
    } //-- void setSecurityRole(int, java.lang.String)

    /**
     *
     * @param securityRoleArray
    **/
    public void setSecurityRole(java.lang.String[] securityRoleArray)
    {
        //-- copy array
        _securityRoleList.clear();
        for (int i = 0; i < securityRoleArray.length; i++) {
            _securityRoleList.add(securityRoleArray[i]);
        }
    } //-- void setSecurityRole(java.lang.String)

    /**
     *
     * @param reader
    **/
    public static com.iharding.generator.xml.Security unmarshal(java.io.Reader reader)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        return (com.iharding.generator.xml.Security) Unmarshaller.unmarshal(com.iharding.generator.xml.Security.class, reader);
    } //-- com.javanovic.karapansapi.xml.Security unmarshal(java.io.Reader)

    /**
    **/
    public void validate()
        throws org.exolab.castor.xml.ValidationException
    {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    } //-- void validate()

}

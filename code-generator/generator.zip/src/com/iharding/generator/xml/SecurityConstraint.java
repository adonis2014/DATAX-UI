

package com.iharding.generator.xml;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.io.Reader;
import java.io.Serializable;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Enumeration;
import org.exolab.castor.xml.*;
import org.exolab.castor.xml.MarshalException;
import org.exolab.castor.xml.ValidationException;
import org.xml.sax.DocumentHandler;

/**
 * Web Resource definition in web.xml file.
 * @version $Revision$ $Date$
**/
public class SecurityConstraint implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    private java.lang.String _name;

    private java.util.ArrayList _urlPatternList;

    private java.util.ArrayList _securityRoleList;


      //----------------/
     //- Constructors -/
    //----------------/

    public SecurityConstraint() {
        super();
        _urlPatternList = new ArrayList();
        _securityRoleList = new ArrayList();
    } //-- com.javanovic.karapansapi.xml.SecurityConstraint()


      //-----------/
     //- Methods -/
    //-----------/

    /**
     *
     * @param vSecurityRole
    **/
    public void addSecurityRole(java.lang.String vSecurityRole)
        throws java.lang.IndexOutOfBoundsException
    {
        _securityRoleList.add(vSecurityRole);
    } //-- void addSecurityRole(java.lang.String)

    /**
     *
     * @param vUrlPattern
    **/
    public void addUrlPattern(java.lang.String vUrlPattern)
        throws java.lang.IndexOutOfBoundsException
    {
        _urlPatternList.add(vUrlPattern);
    } //-- void addUrlPattern(java.lang.String)

    /**
    **/
    public void clearSecurityRole()
    {
        _securityRoleList.clear();
    } //-- void clearSecurityRole()

    /**
    **/
    public void clearUrlPattern()
    {
        _urlPatternList.clear();
    } //-- void clearUrlPattern()

    /**
    **/
    public java.util.Enumeration enumerateSecurityRole()
    {
        return new org.exolab.castor.util.IteratorEnumeration(_securityRoleList.iterator());
    } //-- java.util.Enumeration enumerateSecurityRole()

    /**
    **/
    public java.util.Enumeration enumerateUrlPattern()
    {
        return new org.exolab.castor.util.IteratorEnumeration(_urlPatternList.iterator());
    } //-- java.util.Enumeration enumerateUrlPattern()

    /**
    **/
    public java.lang.String getName()
    {
        return this._name;
    } //-- java.lang.String getName()

    /**
     *
     * @param index
    **/
    public java.lang.String getSecurityRole(int index)
        throws java.lang.IndexOutOfBoundsException
    {
        //-- check bounds for index
        if ((index < 0) || (index > _securityRoleList.size())) {
            throw new IndexOutOfBoundsException();
        }

        return (String)_securityRoleList.get(index);
    } //-- java.lang.String getSecurityRole(int)

    /**
    **/
    public java.lang.String[] getSecurityRole()
    {
        int size = _securityRoleList.size();
        java.lang.String[] mArray = new String[size];
        for (int index = 0; index < size; index++) {
            mArray[index] = (String)_securityRoleList.get(index);
        }
        return mArray;
    } //-- java.lang.String[] getSecurityRole()

    /**
    **/
    public int getSecurityRoleCount()
    {
        return _securityRoleList.size();
    } //-- int getSecurityRoleCount()

    /**
     *
     * @param index
    **/
    public java.lang.String getUrlPattern(int index)
        throws java.lang.IndexOutOfBoundsException
    {
        //-- check bounds for index
        if ((index < 0) || (index > _urlPatternList.size())) {
            throw new IndexOutOfBoundsException();
        }

        return (String)_urlPatternList.get(index);
    } //-- java.lang.String getUrlPattern(int)

    /**
    **/
    public java.lang.String[] getUrlPattern()
    {
        int size = _urlPatternList.size();
        java.lang.String[] mArray = new String[size];
        for (int index = 0; index < size; index++) {
            mArray[index] = (String)_urlPatternList.get(index);
        }
        return mArray;
    } //-- java.lang.String[] getUrlPattern()

    /**
    **/
    public int getUrlPatternCount()
    {
        return _urlPatternList.size();
    } //-- int getUrlPatternCount()

    /**
    **/
    public boolean isValid()
    {
        try {
            validate();
        }
        catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    } //-- boolean isValid()

    /**
     *
     * @param out
    **/
    public void marshal(java.io.Writer out)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {

        Marshaller.marshal(this, out);
    } //-- void marshal(java.io.Writer)

    /**
     *
     * @param handler
    **/
    public void marshal(org.xml.sax.DocumentHandler handler)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {

        Marshaller.marshal(this, handler);
    } //-- void marshal(org.xml.sax.DocumentHandler)

    /**
     *
     * @param vSecurityRole
    **/
    public boolean removeSecurityRole(java.lang.String vSecurityRole)
    {
        boolean removed = _securityRoleList.remove(vSecurityRole);
        return removed;
    } //-- boolean removeSecurityRole(java.lang.String)

    /**
     *
     * @param vUrlPattern
    **/
    public boolean removeUrlPattern(java.lang.String vUrlPattern)
    {
        boolean removed = _urlPatternList.remove(vUrlPattern);
        return removed;
    } //-- boolean removeUrlPattern(java.lang.String)

    /**
     *
     * @param name
    **/
    public void setName(java.lang.String name)
    {
        this._name = name;
    } //-- void setName(java.lang.String)

    /**
     *
     * @param index
     * @param vSecurityRole
    **/
    public void setSecurityRole(int index, java.lang.String vSecurityRole)
        throws java.lang.IndexOutOfBoundsException
    {
        //-- check bounds for index
        if ((index < 0) || (index > _securityRoleList.size())) {
            throw new IndexOutOfBoundsException();
        }
        _securityRoleList.set(index, vSecurityRole);
    } //-- void setSecurityRole(int, java.lang.String)

    /**
     *
     * @param securityRoleArray
    **/
    public void setSecurityRole(java.lang.String[] securityRoleArray)
    {
        //-- copy array
        _securityRoleList.clear();
        for (int i = 0; i < securityRoleArray.length; i++) {
            _securityRoleList.add(securityRoleArray[i]);
        }
    } //-- void setSecurityRole(java.lang.String)

    /**
     *
     * @param index
     * @param vUrlPattern
    **/
    public void setUrlPattern(int index, java.lang.String vUrlPattern)
        throws java.lang.IndexOutOfBoundsException
    {
        //-- check bounds for index
        if ((index < 0) || (index > _urlPatternList.size())) {
            throw new IndexOutOfBoundsException();
        }
        _urlPatternList.set(index, vUrlPattern);
    } //-- void setUrlPattern(int, java.lang.String)

    /**
     *
     * @param urlPatternArray
    **/
    public void setUrlPattern(java.lang.String[] urlPatternArray)
    {
        //-- copy array
        _urlPatternList.clear();
        for (int i = 0; i < urlPatternArray.length; i++) {
            _urlPatternList.add(urlPatternArray[i]);
        }
    } //-- void setUrlPattern(java.lang.String)

    /**
     *
     * @param reader
    **/
    public static com.iharding.generator.xml.SecurityConstraint unmarshal(java.io.Reader reader)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        return (com.iharding.generator.xml.SecurityConstraint) Unmarshaller.unmarshal(com.iharding.generator.xml.SecurityConstraint.class, reader);
    } //-- com.javanovic.karapansapi.xml.SecurityConstraint unmarshal(java.io.Reader)

    /**
    **/
    public void validate()
        throws org.exolab.castor.xml.ValidationException
    {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    } //-- void validate()

}

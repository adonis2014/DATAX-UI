

package com.iharding.generator.xml;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.io.Reader;
import java.io.Serializable;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Enumeration;
import org.exolab.castor.xml.*;
import org.exolab.castor.xml.MarshalException;
import org.exolab.castor.xml.ValidationException;
import org.xml.sax.DocumentHandler;

/**
 *
 * @version $Revision$ $Date$
**/
public class Strutscreator implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Information about project properties
    **/
    private Property _property;

    /**
     * Information about project build property
    **/
    private Build _build;

    /**
     * Information about database
    **/
    private Database _database;

    /**
     * Information about security constraint
    **/
    private Security _security;

    /**
     * Pair code/display used by dropdown list/radio button
    **/
    private java.util.ArrayList _globalValueRefList;

    /**
     * Reference that will be put in application or session scope
    **/
    private java.util.ArrayList _globalReferenceList;

    private java.util.ArrayList _beanList;

    private java.util.ArrayList _menuList;


      //----------------/
     //- Constructors -/
    //----------------/

    public Strutscreator() {
        super();
        _globalValueRefList = new ArrayList();
        _globalReferenceList = new ArrayList();
        _beanList = new ArrayList();
        _menuList = new ArrayList();
    } //-- com.javanovic.karapansapi.xml.Strutscreator()


      //-----------/
     //- Methods -/
    //-----------/

    /**
     *
     * @param vBean
    **/
    public void addBean(Bean vBean)
        throws java.lang.IndexOutOfBoundsException
    {
        _beanList.add(vBean);
    } //-- void addBean(Bean)

    /**
     *
     * @param vGlobalReference
    **/
    public void addGlobalReference(GlobalReference vGlobalReference)
        throws java.lang.IndexOutOfBoundsException
    {
        _globalReferenceList.add(vGlobalReference);
    } //-- void addGlobalReference(GlobalReference)

    /**
     *
     * @param vGlobalValueRef
    **/
    public void addGlobalValueRef(GlobalValueRef vGlobalValueRef)
        throws java.lang.IndexOutOfBoundsException
    {
        _globalValueRefList.add(vGlobalValueRef);
    } //-- void addGlobalValueRef(GlobalValueRef)

    /**
     *
     * @param vMenu
    **/
    public void addMenu(Menu vMenu)
        throws java.lang.IndexOutOfBoundsException
    {
        _menuList.add(vMenu);
    } //-- void addMenu(Menu)

    /**
    **/
    public void clearBean()
    {
        _beanList.clear();
    } //-- void clearBean()

    /**
    **/
    public void clearGlobalReference()
    {
        _globalReferenceList.clear();
    } //-- void clearGlobalReference()

    /**
    **/
    public void clearGlobalValueRef()
    {
        _globalValueRefList.clear();
    } //-- void clearGlobalValueRef()

    /**
    **/
    public void clearMenu()
    {
        _menuList.clear();
    } //-- void clearMenu()

    /**
    **/
    public java.util.Enumeration enumerateBean()
    {
        return new org.exolab.castor.util.IteratorEnumeration(_beanList.iterator());
    } //-- java.util.Enumeration enumerateBean()

    /**
    **/
    public java.util.Enumeration enumerateGlobalReference()
    {
        return new org.exolab.castor.util.IteratorEnumeration(_globalReferenceList.iterator());
    } //-- java.util.Enumeration enumerateGlobalReference()

    /**
    **/
    public java.util.Enumeration enumerateGlobalValueRef()
    {
        return new org.exolab.castor.util.IteratorEnumeration(_globalValueRefList.iterator());
    } //-- java.util.Enumeration enumerateGlobalValueRef()

    /**
    **/
    public java.util.Enumeration enumerateMenu()
    {
        return new org.exolab.castor.util.IteratorEnumeration(_menuList.iterator());
    } //-- java.util.Enumeration enumerateMenu()

    /**
     *
     * @param index
    **/
    public Bean getBean(int index)
        throws java.lang.IndexOutOfBoundsException
    {
        //-- check bounds for index
        if ((index < 0) || (index > _beanList.size())) {
            throw new IndexOutOfBoundsException();
        }

        return (Bean) _beanList.get(index);
    } //-- Bean getBean(int)

    /**
    **/
    public Bean[] getBean()
    {
        int size = _beanList.size();
        Bean[] mArray = new Bean[size];
        for (int index = 0; index < size; index++) {
            mArray[index] = (Bean) _beanList.get(index);
        }
        return mArray;
    } //-- Bean[] getBean()

    /**
    **/
    public int getBeanCount()
    {
        return _beanList.size();
    } //-- int getBeanCount()

    /**
    **/
    public Build getBuild()
    {
        return this._build;
    } //-- Build getBuild()

    /**
    **/
    public Database getDatabase()
    {
        return this._database;
    } //-- Database getDatabase()

    /**
     *
     * @param index
    **/
    public GlobalReference getGlobalReference(int index)
        throws java.lang.IndexOutOfBoundsException
    {
        //-- check bounds for index
        if ((index < 0) || (index > _globalReferenceList.size())) {
            throw new IndexOutOfBoundsException();
        }

        return (GlobalReference) _globalReferenceList.get(index);
    } //-- GlobalReference getGlobalReference(int)

    /**
    **/
    public GlobalReference[] getGlobalReference()
    {
        int size = _globalReferenceList.size();
        GlobalReference[] mArray = new GlobalReference[size];
        for (int index = 0; index < size; index++) {
            mArray[index] = (GlobalReference) _globalReferenceList.get(index);
        }
        return mArray;
    } //-- GlobalReference[] getGlobalReference()

    /**
    **/
    public int getGlobalReferenceCount()
    {
        return _globalReferenceList.size();
    } //-- int getGlobalReferenceCount()

    /**
     *
     * @param index
    **/
    public GlobalValueRef getGlobalValueRef(int index)
        throws java.lang.IndexOutOfBoundsException
    {
        //-- check bounds for index
        if ((index < 0) || (index > _globalValueRefList.size())) {
            throw new IndexOutOfBoundsException();
        }

        return (GlobalValueRef) _globalValueRefList.get(index);
    } //-- GlobalValueRef getGlobalValueRef(int)

    /**
    **/
    public GlobalValueRef[] getGlobalValueRef()
    {
        int size = _globalValueRefList.size();
        GlobalValueRef[] mArray = new GlobalValueRef[size];
        for (int index = 0; index < size; index++) {
            mArray[index] = (GlobalValueRef) _globalValueRefList.get(index);
        }
        return mArray;
    } //-- GlobalValueRef[] getGlobalValueRef()

    /**
    **/
    public int getGlobalValueRefCount()
    {
        return _globalValueRefList.size();
    } //-- int getGlobalValueRefCount()

    /**
     *
     * @param index
    **/
    public Menu getMenu(int index)
        throws java.lang.IndexOutOfBoundsException
    {
        //-- check bounds for index
        if ((index < 0) || (index > _menuList.size())) {
            throw new IndexOutOfBoundsException();
        }

        return (Menu) _menuList.get(index);
    } //-- Menu getMenu(int)

    /**
    **/
    public Menu[] getMenu()
    {
        int size = _menuList.size();
        Menu[] mArray = new Menu[size];
        for (int index = 0; index < size; index++) {
            mArray[index] = (Menu) _menuList.get(index);
        }
        return mArray;
    } //-- Menu[] getMenu()

    /**
    **/
    public int getMenuCount()
    {
        return _menuList.size();
    } //-- int getMenuCount()

    /**
    **/
    public Property getProperty()
    {
        return this._property;
    } //-- Property getProperty()

    /**
    **/
    public Security getSecurity()
    {
        return this._security;
    } //-- Security getSecurity()

    /**
    **/
    public boolean isValid()
    {
        try {
            validate();
        }
        catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    } //-- boolean isValid()

    /**
     *
     * @param out
    **/
    public void marshal(java.io.Writer out)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {

        Marshaller.marshal(this, out);
    } //-- void marshal(java.io.Writer)

    /**
     *
     * @param handler
    **/
    public void marshal(org.xml.sax.DocumentHandler handler)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {

        Marshaller.marshal(this, handler);
    } //-- void marshal(org.xml.sax.DocumentHandler)

    /**
     *
     * @param vBean
    **/
    public boolean removeBean(Bean vBean)
    {
        boolean removed = _beanList.remove(vBean);
        return removed;
    } //-- boolean removeBean(Bean)

    /**
     *
     * @param vGlobalReference
    **/
    public boolean removeGlobalReference(GlobalReference vGlobalReference)
    {
        boolean removed = _globalReferenceList.remove(vGlobalReference);
        return removed;
    } //-- boolean removeGlobalReference(GlobalReference)

    /**
     *
     * @param vGlobalValueRef
    **/
    public boolean removeGlobalValueRef(GlobalValueRef vGlobalValueRef)
    {
        boolean removed = _globalValueRefList.remove(vGlobalValueRef);
        return removed;
    } //-- boolean removeGlobalValueRef(GlobalValueRef)

    /**
     *
     * @param vMenu
    **/
    public boolean removeMenu(Menu vMenu)
    {
        boolean removed = _menuList.remove(vMenu);
        return removed;
    } //-- boolean removeMenu(Menu)

    /**
     *
     * @param index
     * @param vBean
    **/
    public void setBean(int index, Bean vBean)
        throws java.lang.IndexOutOfBoundsException
    {
        //-- check bounds for index
        if ((index < 0) || (index > _beanList.size())) {
            throw new IndexOutOfBoundsException();
        }
        _beanList.set(index, vBean);
    } //-- void setBean(int, Bean)

    /**
     *
     * @param beanArray
    **/
    public void setBean(Bean[] beanArray)
    {
        //-- copy array
        _beanList.clear();
        for (int i = 0; i < beanArray.length; i++) {
            _beanList.add(beanArray[i]);
        }
    } //-- void setBean(Bean)

    /**
     *
     * @param build
    **/
    public void setBuild(Build build)
    {
        this._build = build;
    } //-- void setBuild(Build)

    /**
     *
     * @param database
    **/
    public void setDatabase(Database database)
    {
        this._database = database;
    } //-- void setDatabase(Database)

    /**
     *
     * @param index
     * @param vGlobalReference
    **/
    public void setGlobalReference(int index, GlobalReference vGlobalReference)
        throws java.lang.IndexOutOfBoundsException
    {
        //-- check bounds for index
        if ((index < 0) || (index > _globalReferenceList.size())) {
            throw new IndexOutOfBoundsException();
        }
        _globalReferenceList.set(index, vGlobalReference);
    } //-- void setGlobalReference(int, GlobalReference)

    /**
     *
     * @param globalReferenceArray
    **/
    public void setGlobalReference(GlobalReference[] globalReferenceArray)
    {
        //-- copy array
        _globalReferenceList.clear();
        for (int i = 0; i < globalReferenceArray.length; i++) {
            _globalReferenceList.add(globalReferenceArray[i]);
        }
    } //-- void setGlobalReference(GlobalReference)

    /**
     *
     * @param index
     * @param vGlobalValueRef
    **/
    public void setGlobalValueRef(int index, GlobalValueRef vGlobalValueRef)
        throws java.lang.IndexOutOfBoundsException
    {
        //-- check bounds for index
        if ((index < 0) || (index > _globalValueRefList.size())) {
            throw new IndexOutOfBoundsException();
        }
        _globalValueRefList.set(index, vGlobalValueRef);
    } //-- void setGlobalValueRef(int, GlobalValueRef)

    /**
     *
     * @param globalValueRefArray
    **/
    public void setGlobalValueRef(GlobalValueRef[] globalValueRefArray)
    {
        //-- copy array
        _globalValueRefList.clear();
        for (int i = 0; i < globalValueRefArray.length; i++) {
            _globalValueRefList.add(globalValueRefArray[i]);
        }
    } //-- void setGlobalValueRef(GlobalValueRef)

    /**
     *
     * @param index
     * @param vMenu
    **/
    public void setMenu(int index, Menu vMenu)
        throws java.lang.IndexOutOfBoundsException
    {
        //-- check bounds for index
        if ((index < 0) || (index > _menuList.size())) {
            throw new IndexOutOfBoundsException();
        }
        _menuList.set(index, vMenu);
    } //-- void setMenu(int, Menu)

    /**
     *
     * @param menuArray
    **/
    public void setMenu(Menu[] menuArray)
    {
        //-- copy array
        _menuList.clear();
        for (int i = 0; i < menuArray.length; i++) {
            _menuList.add(menuArray[i]);
        }
    } //-- void setMenu(Menu)

    /**
     *
     * @param property
    **/
    public void setProperty(Property property)
    {
        this._property = property;
    } //-- void setProperty(Property)

    /**
     *
     * @param security
    **/
    public void setSecurity(Security security)
    {
        this._security = security;
    } //-- void setSecurity(Security)

    /**
     *
     * @param reader
    **/
    public static com.iharding.generator.xml.Strutscreator unmarshal(java.io.Reader reader)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        return (com.iharding.generator.xml.Strutscreator) Unmarshaller.unmarshal(com.iharding.generator.xml.Strutscreator.class, reader);
    } //-- com.javanovic.karapansapi.xml.Strutscreator unmarshal(java.io.Reader)

    /**
    **/
    public void validate()
        throws org.exolab.castor.xml.ValidationException
    {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    } //-- void validate()

}

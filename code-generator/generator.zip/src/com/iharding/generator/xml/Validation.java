

package com.iharding.generator.xml;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.io.Reader;
import java.io.Serializable;
import java.io.Writer;
import org.exolab.castor.xml.*;
import org.exolab.castor.xml.MarshalException;
import org.exolab.castor.xml.ValidationException;
import org.xml.sax.DocumentHandler;

/**
 *
 * @version $Revision$ $Date$
**/
public class Validation implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    private boolean _required;

    /**
     * keeps track of state for field: _required
    **/
    private boolean _has_required;

    private int _minLength;

    /**
     * keeps track of state for field: _minLength
    **/
    private boolean _has_minLength;

    private int _maxLength;

    /**
     * keeps track of state for field: _maxLength
    **/
    private boolean _has_maxLength;

    private int _min;

    /**
     * keeps track of state for field: _min
    **/
    private boolean _has_min;

    private int _max;

    /**
     * keeps track of state for field: _max
    **/
    private boolean _has_max;

    private java.lang.String _mask;

    private java.lang.String _maskmsg;


      //----------------/
     //- Constructors -/
    //----------------/

    public Validation() {
        super();
    } //-- com.javanovic.karapansapi.xml.Validation()


      //-----------/
     //- Methods -/
    //-----------/

    /**
    **/
    public void deleteMax()
    {
        this._has_max= false;
    } //-- void deleteMax()

    /**
    **/
    public void deleteMaxLength()
    {
        this._has_maxLength= false;
    } //-- void deleteMaxLength()

    /**
    **/
    public void deleteMin()
    {
        this._has_min= false;
    } //-- void deleteMin()

    /**
    **/
    public void deleteMinLength()
    {
        this._has_minLength= false;
    } //-- void deleteMinLength()

    /**
    **/
    public java.lang.String getMask()
    {
        return this._mask;
    } //-- java.lang.String getMask()

    /**
    **/
    public java.lang.String getMaskmsg()
    {
        return this._maskmsg;
    } //-- java.lang.String getMaskmsg()

    /**
    **/
    public int getMax()
    {
        return this._max;
    } //-- int getMax()

    /**
    **/
    public int getMaxLength()
    {
        return this._maxLength;
    } //-- int getMaxLength()

    /**
    **/
    public int getMin()
    {
        return this._min;
    } //-- int getMin()

    /**
    **/
    public int getMinLength()
    {
        return this._minLength;
    } //-- int getMinLength()

    /**
    **/
    public boolean getRequired()
    {
        return this._required;
    } //-- boolean getRequired()

    /**
    **/
    public boolean hasMax()
    {
        return this._has_max;
    } //-- boolean hasMax()

    /**
    **/
    public boolean hasMaxLength()
    {
        return this._has_maxLength;
    } //-- boolean hasMaxLength()

    /**
    **/
    public boolean hasMin()
    {
        return this._has_min;
    } //-- boolean hasMin()

    /**
    **/
    public boolean hasMinLength()
    {
        return this._has_minLength;
    } //-- boolean hasMinLength()

    /**
    **/
    public boolean hasRequired()
    {
        return this._has_required;
    } //-- boolean hasRequired()

    /**
    **/
    public boolean isValid()
    {
        try {
            validate();
        }
        catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    } //-- boolean isValid()

    /**
     *
     * @param out
    **/
    public void marshal(java.io.Writer out)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {

        Marshaller.marshal(this, out);
    } //-- void marshal(java.io.Writer)

    /**
     *
     * @param handler
    **/
    public void marshal(org.xml.sax.DocumentHandler handler)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {

        Marshaller.marshal(this, handler);
    } //-- void marshal(org.xml.sax.DocumentHandler)

    /**
     *
     * @param mask
    **/
    public void setMask(java.lang.String mask)
    {
        this._mask = mask;
    } //-- void setMask(java.lang.String)

    /**
     *
     * @param maskmsg
    **/
    public void setMaskmsg(java.lang.String maskmsg)
    {
        this._maskmsg = maskmsg;
    } //-- void setMaskmsg(java.lang.String)

    /**
     *
     * @param max
    **/
    public void setMax(int max)
    {
        this._max = max;
        this._has_max = true;
    } //-- void setMax(int)

    /**
     *
     * @param maxLength
    **/
    public void setMaxLength(int maxLength)
    {
        this._maxLength = maxLength;
        this._has_maxLength = true;
    } //-- void setMaxLength(int)

    /**
     *
     * @param min
    **/
    public void setMin(int min)
    {
        this._min = min;
        this._has_min = true;
    } //-- void setMin(int)

    /**
     *
     * @param minLength
    **/
    public void setMinLength(int minLength)
    {
        this._minLength = minLength;
        this._has_minLength = true;
    } //-- void setMinLength(int)

    /**
     *
     * @param required
    **/
    public void setRequired(boolean required)
    {
        this._required = required;
        this._has_required = true;
    } //-- void setRequired(boolean)

    /**
     *
     * @param reader
    **/
    public static com.iharding.generator.xml.Validation unmarshal(java.io.Reader reader)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        return (com.iharding.generator.xml.Validation) Unmarshaller.unmarshal(com.iharding.generator.xml.Validation.class, reader);
    } //-- com.javanovic.karapansapi.xml.Validation unmarshal(java.io.Reader)

    /**
    **/
    public void validate()
        throws org.exolab.castor.xml.ValidationException
    {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    } //-- void validate()

}



package com.iharding.generator.xml;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.io.Reader;
import java.io.Serializable;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Enumeration;
import org.exolab.castor.xml.*;
import org.exolab.castor.xml.MarshalException;
import org.exolab.castor.xml.ValidationException;
import org.xml.sax.DocumentHandler;

/**
 *
 * @version $Revision$ $Date$
**/
public class Value implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    private java.lang.String _widget;

    private java.util.ArrayList _choiceList;

    private java.lang.String _globalValueRef;


      //----------------/
     //- Constructors -/
    //----------------/

    public Value() {
        super();
        _choiceList = new ArrayList();
    } //-- com.javanovic.karapansapi.xml.Value()


      //-----------/
     //- Methods -/
    //-----------/

    /**
     *
     * @param vChoice
    **/
    public void addChoice(Choice vChoice)
        throws java.lang.IndexOutOfBoundsException
    {
        _choiceList.add(vChoice);
    } //-- void addChoice(Choice)

    /**
    **/
    public void clearChoice()
    {
        _choiceList.clear();
    } //-- void clearChoice()

    /**
    **/
    public java.util.Enumeration enumerateChoice()
    {
        return new org.exolab.castor.util.IteratorEnumeration(_choiceList.iterator());
    } //-- java.util.Enumeration enumerateChoice()

    /**
     *
     * @param index
    **/
    public Choice getChoice(int index)
        throws java.lang.IndexOutOfBoundsException
    {
        //-- check bounds for index
        if ((index < 0) || (index > _choiceList.size())) {
            throw new IndexOutOfBoundsException();
        }

        return (Choice) _choiceList.get(index);
    } //-- Choice getChoice(int)

    /**
    **/
    public Choice[] getChoice()
    {
        int size = _choiceList.size();
        Choice[] mArray = new Choice[size];
        for (int index = 0; index < size; index++) {
            mArray[index] = (Choice) _choiceList.get(index);
        }
        return mArray;
    } //-- Choice[] getChoice()

    /**
    **/
    public int getChoiceCount()
    {
        return _choiceList.size();
    } //-- int getChoiceCount()

    /**
    **/
    public java.lang.String getGlobalValueRef()
    {
        return this._globalValueRef;
    } //-- java.lang.String getGlobalValueRef()

    /**
    **/
    public java.lang.String getWidget()
    {
        return this._widget;
    } //-- java.lang.String getWidget()

    /**
    **/
    public boolean isValid()
    {
        try {
            validate();
        }
        catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    } //-- boolean isValid()

    /**
     *
     * @param out
    **/
    public void marshal(java.io.Writer out)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {

        Marshaller.marshal(this, out);
    } //-- void marshal(java.io.Writer)

    /**
     *
     * @param handler
    **/
    public void marshal(org.xml.sax.DocumentHandler handler)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {

        Marshaller.marshal(this, handler);
    } //-- void marshal(org.xml.sax.DocumentHandler)

    /**
     *
     * @param vChoice
    **/
    public boolean removeChoice(Choice vChoice)
    {
        boolean removed = _choiceList.remove(vChoice);
        return removed;
    } //-- boolean removeChoice(Choice)

    /**
     *
     * @param index
     * @param vChoice
    **/
    public void setChoice(int index, Choice vChoice)
        throws java.lang.IndexOutOfBoundsException
    {
        //-- check bounds for index
        if ((index < 0) || (index > _choiceList.size())) {
            throw new IndexOutOfBoundsException();
        }
        _choiceList.set(index, vChoice);
    } //-- void setChoice(int, Choice)

    /**
     *
     * @param choiceArray
    **/
    public void setChoice(Choice[] choiceArray)
    {
        //-- copy array
        _choiceList.clear();
        for (int i = 0; i < choiceArray.length; i++) {
            _choiceList.add(choiceArray[i]);
        }
    } //-- void setChoice(Choice)

    /**
     *
     * @param globalValueRef
    **/
    public void setGlobalValueRef(java.lang.String globalValueRef)
    {
        this._globalValueRef = globalValueRef;
    } //-- void setGlobalValueRef(java.lang.String)

    /**
     *
     * @param widget
    **/
    public void setWidget(java.lang.String widget)
    {
        this._widget = widget;
    } //-- void setWidget(java.lang.String)

    /**
     *
     * @param reader
    **/
    public static com.iharding.generator.xml.Value unmarshal(java.io.Reader reader)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        return (com.iharding.generator.xml.Value) Unmarshaller.unmarshal(com.iharding.generator.xml.Value.class, reader);
    } //-- com.javanovic.karapansapi.xml.Value unmarshal(java.io.Reader)

    /**
    **/
    public void validate()
        throws org.exolab.castor.xml.ValidationException
    {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    } //-- void validate()

}

package com.iharding.generator.xml;

/**
 * XML exception
 */
public class XMLException extends Exception {

  public Exception detail;

    /**
     * Construct an exception with a reason
     *
     * @param reason Text containing the reason
     */
    public XMLException(String reason) {
	super(reason);
    }

  /**
   * Construct an exception with a reason and an ##
   *
   * @param reason Text containing the reason
   * @param detail A nested exception.
   */
  public XMLException(String reason, Exception detail) {
    this(reason);
    this.detail = detail;
  }
}

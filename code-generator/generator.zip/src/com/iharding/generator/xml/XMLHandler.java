package com.iharding.generator.xml;

import java.io.*;

/**
 * Defines an interface for loading and saving an StrutsCreator object
 */
public interface XMLHandler {

    /**
     * Create a StrutsCreator XML tree based on a file name
     *
     * @param filename Name of the file
     * @return StrutsCreator-object
     * @exception FileNotFoundException Thrown if the file can not be found
     * @exception XMLException Thrown if there were an error during the loading
     */
    public Strutscreator load(String filename) throws FileNotFoundException, XMLException;

    /**
     * Store a Strutscreator XML tree to a file
     *
     * @param filename Name of the file
     * @param tree The Strutscreator tree that should be saved
     * @exception IOException Thrown if the file can not be created
     * @exception XMLException Thrown if there were an error during the saving
     */
    public void save(String filename, Strutscreator tree) throws IOException, XMLException;
}

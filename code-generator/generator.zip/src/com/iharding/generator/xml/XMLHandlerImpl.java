
package com.iharding.generator.xml;

import java.io.*;
import java.util.zip.*;

import org.exolab.castor.xml.*;

/**
 * Defines an interface for loading and saving an Strutscreator object
 */
public class XMLHandlerImpl implements XMLHandler {

  /**
   * Default constructor
   */
  public XMLHandlerImpl() {
  }

  /**
   * Create a Strutscreator XML tree based on a file name
   *
   * @param filename Name of the file
   * @return Strutscreator-object
   * @exception FileNotFoundException Thrown if the file can not be found
   * @exception XMLException Thrown if there were an error during the loading
   */
  public Strutscreator load(String filename) throws FileNotFoundException, XMLException {
    try {
      Strutscreator tree = null;
      InputStream in = null;

      in = new FileInputStream(filename);
      if (filename.toUpperCase().endsWith(".GZ")) {
	in = new GZIPInputStream(in);
      }
      InputStreamReader reader = new InputStreamReader(in,"UTF8");

      tree = (Strutscreator)Unmarshaller.unmarshal(Strutscreator.class, reader);

      reader.close();

      return tree;
    } catch (MarshalException e) {
      System.out.println(e.getMessage());
      throw new XMLException("Unable to unmarshal " + filename, e);
    } catch (ValidationException e) {
      System.out.println(e.getMessage());
      throw new XMLException("Unable to validate " + filename, e);
    } catch (IOException e) {
      System.out.println(e.getMessage());
      throw new XMLException("Unable to open file" + filename, e);
    }
  }

  /**
   * Store a Strutscreator XML tree to a file
   *
   * @param filename Name of the file
   * @param tree The Strutscreator tree that should be saved
   * @exception IOException Thrown if the file can not be created
   * @exception XMLException Thrown if there were an error during the saving
   */
  public void save(String filename, Strutscreator tree) throws IOException, XMLException {
    try {
      String tmpFilename = filename + "_save";
      OutputStream out = null;
      File file=new File(tmpFilename);
      file.getParentFile().mkdirs();
      out = new FileOutputStream(file);
      if (filename.toUpperCase().endsWith(".GZ")) {
	out = new GZIPOutputStream(out);
      }
      OutputStreamWriter writer = new OutputStreamWriter(out,"UTF8");
      Marshaller.marshal( tree, writer );

      writer.close();

      // Rename the file
      File tmpFile = new File(tmpFilename);
      File saveFile = new File(filename);
      if (saveFile.exists() && !saveFile.delete()) {
        throw new XMLException("Error removing old file");
      }
      if (!tmpFile.renameTo(saveFile)) {
        throw new XMLException("Error renaming file '" + tmpFilename +
                               "' to '" + filename + "'");
      }
    } catch (MarshalException e) {
      e.printStackTrace();
      throw new XMLException("Unable to marshal " + filename, e);
    } catch (ValidationException e) {
      e.printStackTrace();
      throw new XMLException("Unable to validate " + filename, e);
    } catch (IOException e) {
      e.printStackTrace();
      throw new XMLException("Unable to save file " + filename, e);
    }
  }

  public String saveWithTrace(String filename, Strutscreator tree) throws IOException, XMLException {
    try {
      String trace = "Trace:\n";
      String tmpFilename = filename + "_save";
      OutputStream out = null;

      trace += "Creating output\n";
      out = new FileOutputStream(tmpFilename);
      if (filename.toUpperCase().endsWith(".GZ")) {
        out = new GZIPOutputStream(out);
      }
      OutputStreamWriter writer = new OutputStreamWriter(out);
      trace += "Marshalling\n";
      Marshaller.marshal( tree, writer );

      trace += "Closing file\n";
      writer.close();

      // Rename the file
      trace += "Rename "+tmpFilename+" to "+filename;
      File tmpFile = new File(tmpFilename);
      File saveFile = new File(filename);
      if (saveFile.exists() && !saveFile.delete()) {
        throw new XMLException("Error removing old file");
      }
      if (!tmpFile.renameTo(saveFile)) {
        throw new XMLException("Error renaming file '" + tmpFilename +
                               "' to '" + filename + "'");
      }
      return trace;
    } catch (MarshalException e) {
      throw new XMLException("Unable to marshal " + filename, e);
    } catch (ValidationException e) {
      throw new XMLException("Unable to validate " + filename, e);
    } catch (IOException e) {
      throw new XMLException("Unable to save file " + filename, e);
    }
  }

}
